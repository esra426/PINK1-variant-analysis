# PINK1 evidence tiers: data and code

Data and analysis code for:

> Demir Ünal E, et al. *Evidence selection shapes genetic burden estimates for PINK1-associated Parkinson disease: a tiered reassessment of population, clinical and functional variant data.* (manuscript under review, 2026)

The study is a secondary analysis of public data only. No patient was recruited or contacted and no identifiable personal data were used.

## What is in this repository

| Folder | Contents |
|---|---|
| `scripts/` | Python analysis scripts, run in the order given in `run_all.sh` |
| `data/raw/` | Public source files that may be redistributed (ClinVar PINK1 extract, gnomAD v4.1 PINK1 export, UniProt sequences, functional tables extracted from Ma et al. 2021 and Broadway et al. 2022). Files you must download yourself are listed in `data/raw/README.md`. |
| `data/derived/` | Tables produced by the analysis: variant-level evidence table (477 ClinVar variants), evidence-tier frequencies, homozygote tests, Supporting Tables S1–S13, the two-dataset workbook and the pathogenic-mutation workbook (148 mutations, 514 published patients) |
| `figures/` | Figures 1–4 and S1 as PNG |
| `out/` | Created by `run_all.sh` |

## Reproduce

```bash
pip install -r requirements.txt
bash run_all.sh
```

Tested with Python 3.13.16, pandas 3.0.5, NumPy 2.5.3, SciPy 1.18.1, Biopython 1.88, matplotlib 3.11.2 and openpyxl 3.1.5. Running `run_all.sh` from the files in `data/raw` reproduces `data/derived/burden_tiers_final.csv` exactly. The last four scripts, which build the pathogenic-mutation workbook, also need the files listed in `data/raw/README.md`.

## Key definitions

- Reference: GRCh38; MANE Select transcript NM_032409.3 / ENST00000321556.5; UniProt Q9BXM7.
- ClinVar review stars: no assertion criteria or no classification = 0; single submitter or conflicting = 1; multiple submitters, no conflicts = 2; expert panel = 3; practice guideline = 4.
- T1: ClinVar P/LP, ≥1 star, Parkinson- or PINK1-related condition. T2: T1 plus NMD-predicted nonsense/frameshift (premature stop at or before c.1438) and canonical splice variants. T3a/T3b/T3: functional-evidence stress tests.
- Carrier frequency 2q(1−q) and expected biallelic genotype frequency q², with q = Σ AC/AN over included variants.
- MCAF = a·√(K/f), with K = 5×10⁻⁵, f = 0.5, a = 0.5 (0.0050); alternative √(K·a/f) = 0.0071.

ACMG/AMP criteria in the derived tables are candidates for research use, not clinical classifications, and a pathogenic variant does not by itself establish a diagnosis of recessive PINK1-PD.

## Data sources, licences and attribution

See [`DATA_SOURCES.md`](DATA_SOURCES.md). In short, ClinVar is used with attribution; gnomAD data are under the Open Database License (ODbL v1.0); UniProt and the two functional studies are CC BY 4.0. The Yin & Dieriks (2025) supplementary tables and MDSGene content are not redistributed.

## Licence

- Code (`scripts/`, `run_all.sh`): MIT licence (`LICENSE`).
- Derived data (`data/derived/`): Open Database License v1.0 (`DATA_LICENSE.md`), because they contain data derived from gnomAD. Attribute the sources listed in `DATA_SOURCES.md`.

## Citation

Please cite the article (and the Zenodo archive of this repository, DOI to be added) together with the original data sources. Machine-readable metadata are in `CITATION.cff`.

## Contact

Esra Demir Ünal, Department of Neurology, Ankara Yıldırım Beyazıt University Faculty of Medicine, Ankara, Türkiye.
