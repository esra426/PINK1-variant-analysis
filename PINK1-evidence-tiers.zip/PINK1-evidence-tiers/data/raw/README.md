# Raw inputs

Included (redistributable): `clinvar_pink1_region.vcf`, `gnomAD_v4.1.2_ENSG00000158828_2026_10_16_16_34_55.csv`, `pink1.fasta`, `orthologs.fasta`, `uniprotkb_PINK1_2026_10_16.fasta`, `ma2021.txt`, `broadway.txt`. Checksums: `../../MD5SUMS_raw.txt`.

Add these yourself before running the last four scripts (`s14`–`s18`):

1. `sj-xlsx-2-pkn-10.1177_1877718x241304814.xlsx` and `sj-xlsx-4-pkn-10.1177_1877718x241304814.xlsx`: Supplementary Tables 2 and 4 of Yin & Dieriks (2025), from https://doi.org/10.1177/1877718X241304814.
2. `MDSGene_PINK1_overview.txt`: save the MDSGene PARK-PINK1 “Overview of included studies” page (https://www.mdsgene.org) as PDF and convert it with `pdftotext -layout`.

The ClinVar extract was made from the full release with
`tabix -h clinvar_20261011.vcf.gz 1:20633253-20656420 > clinvar_pink1_region.vcf`
(https://ftp.ncbi.nlm.nih.gov/pub/clinvar/vcf_GRCh38/). The region includes the neighbouring DDOST gene; DDOST-only records are excluded by `s1_harmonize.py`.
