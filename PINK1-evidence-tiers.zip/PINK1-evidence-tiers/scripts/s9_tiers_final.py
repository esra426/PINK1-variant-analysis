"""Final evidence tiers (T1, T2a, T2b, T3a, T3b, T3), confidence intervals and BA1 scan used in the manuscript."""
import pandas as pd, numpy as np, re, json
from scipy import stats
rng=np.random.default_rng(7)
cv=pd.read_csv('data/clinvar_final.csv'); g=pd.read_pickle('data/gnomad_final.pkl')
cv['pd_related']=cv.dn.fillna('').str.lower().str.contains('parkinson|pink1')
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]
def ptc(p,v,c):
    if v=='stop_gained': return c
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',str(p)); return 3*(int(m.group(1))+int(m.group(2))-1) if m else np.nan
g['c_num']=g['Transcript Consequence'].str.extract(r'c\.(\d+)')[0].astype(float)
g['ptc']=[ptc(p,v,c) for p,v,c in zip(g['Protein Consequence'],g['VEP Annotation'],g.c_num)]
blb=set(cv[cv.cls=='B/LB'].key); ok=~g.Flags.fillna('').str.contains('lof_flag|lcr')&~g.key.isin(blb)
nmd=g['VEP Annotation'].isin(['stop_gained','frameshift_variant'])&(g.ptc<=1438)&ok          # PTC <= c.1438: NMD predicted
spl=g['VEP Annotation'].isin(['splice_acceptor_variant','splice_donor_variant'])&ok
t1=g.key.isin(T1.key); P=g['Filters - joint']=='PASS'; T2=t1|nmd|spl
br=['p.Met318Leu','p.Val418Met','p.Ala339Thr','p.Asp525Asn']                                   # Broadway 2022 assay-impaired VUS
ma=['p.Ser419Pro','p.Glu240Lys','p.Leu369Pro','p.Gly386Ala','p.Pro416Leu','p.Leu489Pro','p.Gly409Arg','p.Ile368Asn']  # Ma 2021 P/LP
esc=set(T1[T1.p.isin(['p.Tyr444MetfsTer39','p.Tyr466LeufsTer49','p.Arg492Ter','p.Arg501Ter','p.Lys520ArgfsTer3','p.Gln534Ter'])].key)
top=g[T2&P].sort_values('Allele Count').key.iloc[-1]
sets={'T1':t1,'T1 minus predicted NMD-escape':g.key.isin(set(T1.key)-esc),'T2a':t1|nmd,'T2b':T2,'T2b minus p.Arg492Ter':T2&(g.key!=top),
      'T3a':T2|g['Protein Consequence'].isin(br),'T3b':T2|g['Protein Consequence'].isin(ma),'T3':T2|g['Protein Consequence'].isin(br+ma)}
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','South Asian','Remaining']
rows=[]
for nm,s in sets.items():
    sub=g[s&P]
    for pop in ['Overall']+POPS:
        ac=(sub['Allele Count'] if pop=='Overall' else sub[f'Allele Count {pop}']).values.astype(float)
        an=(sub['Allele Number'] if pop=='Overall' else sub[f'Allele Number {pop}']).values.astype(float)
        m=an>0; ac,an=ac[m],an[m]; q=(ac/an).sum(); A=int(ac.sum()); man=float(np.median(an))
        if A>=10:
            se=np.sqrt((ac/an*(1-ac/an)/an).sum()); lo,hi=q-1.96*se,q+1.96*se; meth='delta method'
            bs=(rng.poisson(ac,(10000,len(ac)))/an).sum(1); blo,bhi=np.percentile(bs,[2.5,97.5])
        else:
            lo=stats.chi2.ppf(.025,2*A)/2/man if A>0 else 0.0; hi=stats.chi2.ppf(.975,2*A+2)/2/man; meth='exact Poisson (AC<10)'; blo,bhi=lo,hi
        rows.append(dict(set=nm,population=pop,variants_included=int((ac>0).sum()),AC=A,median_AN=int(man),q=q,q_lo=lo,q_hi=hi,ci_method=meth,boot_lo=blo,boot_hi=bhi,
            carrier_1_in=(1/(2*q*(1-q)) if q>0 else np.inf),biallelic_per_million=q*q*1e6,biallelic_lo=lo*lo*1e6,biallelic_hi=hi*hi*1e6))
B=pd.DataFrame(rows); B.to_csv('out/burden_tiers_final.csv',index=False)
ba=g[g['GroupMax FAF frequency']>=0.05].assign(clinvar=lambda d:d.key.map(cv.set_index('key').cls))
print(B[B.population=='Overall'][['set','variants_included','AC','carrier_1_in','biallelic_per_million','biallelic_lo','biallelic_hi']].round(3).to_string(index=False))
print('BA1 variants:',len(ba),'classes:',ba.clinvar.value_counts().to_dict())
