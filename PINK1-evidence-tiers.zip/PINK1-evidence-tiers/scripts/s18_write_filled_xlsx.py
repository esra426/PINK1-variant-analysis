import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
SP='out/intermediate/'
OUT=pd.read_pickle(SP+'OUT.pkl'); P=pd.read_pickle(SP+'P.pkl')
F=Font(name='Arial',size=10); FB=Font(name='Arial',size=10,bold=True,color='FFFFFF'); FT=Font(name='Arial',size=12,bold=True)
SEC={'A':'1F4E79','B':'375623','C':'7F3F00','X':'404040'}
A=['genetic_test','sequencing_platform','sequencing_center','genetic_sample','sample_id','test_date','report_date','laboratory_report_id','genome_build','reference_transcript','transcript_version','sequencing_method','coverage_mean','coverage_gene','coverage_limitations','variant_calling_pipeline','annotation_pipeline','cnv_analysis','structural_variant_analysis']
C=['father_genotype','mother_genotype','siblings_genotype','segregation_analysis','variant_phase','inheritance_pattern','biallelic_status','second_allele_search','genetic_diagnosis_status','phenotype_consistency','clinical_interpretation','report_recommendations','wgs_status','reanalysis_status','reanalysis_date']
def sec(c): return 'A' if c in A else ('C' if c in C else ('B' if c=='gene' or c=='gene_disease_association' or c.startswith('variant1_') or c.startswith('variant2_') else 'X'))
wb=Workbook(); wb.remove(wb.active)
def write(name,df,first_w=34):
    ws=wb.create_sheet(name)
    for j,c in enumerate(df.columns,1):
        h=ws.cell(1,j,c); h.font=FB; h.fill=PatternFill('solid',fgColor=SEC[sec(c)]); h.alignment=Alignment(wrap_text=True,vertical='center')
        L=df[c].astype(str).str.len().quantile(.9)
        ws.column_dimensions[get_column_letter(j)].width=first_w if j==1 else max(12,min(46,L*0.55+6))
    for i,r in enumerate(df.itertuples(index=False),2):
        for j,v in enumerate(r,1):
            c=ws.cell(i,j,v); c.font=Font(name='Arial',size=10,bold=True) if j==1 else F; c.alignment=Alignment(wrap_text=True,vertical='top')
    ws.freeze_panes='B2'; ws.auto_filter.ref=ws.dimensions; ws.row_dimensions[1].height=36
write('Pathogenic_mutations',OUT); write('Published_patients',P)
ws=wb.create_sheet('Notes'); ws.column_dimensions['A'].width=30; ws.column_dimensions['B'].width=120
notes=[('PINK1 pathogenic mutations',''),
('Pathogenic_mutations','One row per mutation (148). Included when at least one source calls it pathogenic: ClinVar P/LP, Ma et al. 2021 P/LP, a P/LP claim in a published case (Yin & Dieriks 2025) or listing in MDSGene. Columns follow your schema A–C; variant 1 is the mutation itself, variant 2 is the second allele of its most frequently published biallelic genotype. evidence_status shows how well current evidence supports the call.'),
('Published_patients','One row per published case report (514) carrying at least one of these mutations, same schema; variant 1 and variant 2 are the patient’s two alleles.'),
('Column colours','Blue = A. test; green = B. gene and variant; brown = C. family and molecular diagnosis; grey = identifiers and extra fields.'),
('Sources','ClinVar VCF 11 Oct 2026 (GRCh38); gnomAD v4.1 export (labelled v4.1.2, 16 Oct 2026; 807,162 individuals); Ma et al. 2021; Broadway et al. 2022; Yin & Dieriks 2025 Suppl. Tables 2 and 4; MDSGene PINK1 pages (19 Oct 2026).'),
('How fields were filled','Every cell is filled. Test fields (A) for database rows describe the source data set (gnomAD sequencing, ClinVar submissions); read depth and allele balance are not distributed in aggregate data, so the site call rate (allele number) is given instead. For published patients, fields the compendium does not report say so explicitly; they can be completed from the original papers.'),
('Important','ACMG/AMP classification and molecular diagnosis are kept separate: a pathogenic variant does not by itself establish recessive PINK1-PD. ACMG criteria are candidates derived from public data (research use), and genetic_diagnosis_status is provisional because phase and CNV testing are not yet extracted from the original papers.')]
for i,(a,b) in enumerate(notes,1):
    ws.cell(i,1,a).font=FT if i==1 else Font(name='Arial',size=10,bold=True); ws.cell(i,2,b).font=F; ws.cell(i,2).alignment=Alignment(wrap_text=True,vertical='top')
wb.save('out/PINK1_pathogenic_mutations_filled.xlsx'); print('ok')
