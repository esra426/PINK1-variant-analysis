"""One-row-per-mutation PINK1 table in the user's schema, every field filled from available data; plus per-patient sheet."""
import pandas as pd, numpy as np, re
SP='out/intermediate/'
U='data/raw/'
VT=pd.read_pickle(SP+'VOUT.pkl').fillna(''); CA=pd.read_pickle(SP+'CA.pkl').fillna(''); LK=pd.read_pickle(SP+'LK.pkl').fillna(''); UCA=pd.read_pickle(SP+'UCA.pkl').fillna('')
g=pd.read_pickle('data/gnomad_final.pkl'); gi=g.set_index('gnomAD ID')
NIND=807162; MAXAN=int(g['Allele Number'].max())
cod=g[g['VEP Annotation'].isin(['missense_variant','synonymous_variant','stop_gained','frameshift_variant'])&(g['Filters - joint']=='PASS')]
GENE_COV=f"{(cod['Allele Number']>=0.9*MAXAN).mean()*100:.1f}% of PINK1 coding variant sites called in ≥90% of gnomAD v4.1 alleles (gene-level proxy; depth files not in export)"
VTi=VT.set_index('variant_id')
A_FIELDS=['genetic_test','sequencing_platform','sequencing_center','genetic_sample','sample_id','test_date','report_date','laboratory_report_id','genome_build','reference_transcript','transcript_version','sequencing_method','coverage_mean','coverage_gene','coverage_limitations','variant_calling_pipeline','annotation_pipeline','cnv_analysis','structural_variant_analysis']
VF=['genomic_hgvs','cDNA_hgvs','protein_hgvs','type','exon_intron','region','zygosity','allele_balance','read_depth','inheritance','classification','classification_date','classification_source','acmg_criteria','functional_evidence','literature_evidence','population_frequency','clinvar_id']
C_FIELDS=['father_genotype','mother_genotype','siblings_genotype','segregation_analysis','variant_phase','inheritance_pattern','biallelic_status','second_allele_search','genetic_diagnosis_status','phenotype_consistency','clinical_interpretation','report_recommendations','wgs_status','reanalysis_status','reanalysis_date']
NR='not reported in source'
def label(v):
    c=v.cDNA_hgvs or v.variant_label; p=v.protein_hgvs
    return ' '.join(x for x in [c,p] if x) or v.variant_label
def supported(e): return e.startswith('Supported') or 'predicted null' in e
def vfields(v,n,zyg,inh):
    """schema variant fields for a Variants-table row v"""
    gid=v.gnomad_id
    return {f'variant{n}_genomic_hgvs':v.genomic_hgvs or 'not in ClinVar or gnomAD (reported in literature only)',
            f'variant{n}_cDNA_hgvs':v.cDNA_hgvs or (f'as reported: {v.cDNA_as_reported}' if v.cDNA_as_reported else 'not derivable from available data'),
            f'variant{n}_protein_hgvs':v.protein_hgvs or ('not applicable (non-coding or CNV)' if v.variant_label else ''),
            f'variant{n}_type':v.variant_type,f'variant{n}_exon_intron':v.exon_intron or 'not determinable (position not reported)',
            f'variant{n}_region':v.region or ('splice region / intron' if 'intron' in str(v.exon_intron) else 'not determinable'),
            f'variant{n}_zygosity':zyg,
            f'variant{n}_allele_balance':'not available (aggregate population/database data; no read-level data)',
            f'variant{n}_read_depth':'not available (aggregate data)' if not gid else f"not in gnomAD export; site called in {gi.loc[gid,'Allele Number']/(2*NIND)*100:.2f}% of 807,162 individuals",
            f'variant{n}_inheritance':inh,
            f'variant{n}_classification':v.classification,f'variant{n}_classification_date':v.classification_date or 'not in ClinVar (no ClinVar classification date)',
            f'variant{n}_classification_source':(f'ClinVar VCV{int(v.clinvar_id):09d}, {v.review_stars:.0f} star(s); ' if v.clinvar_id!='' else '')+f'pathogenic per: {v.pathogenic_sources}',
            f'variant{n}_acmg_criteria':'candidate criteria (research use): '+v.acmg_criteria_candidates,
            f'variant{n}_functional_evidence':v.functional_evidence or 'no functional study in Ma 2021 or Broadway 2022',
            f'variant{n}_literature_evidence':v.literature_evidence+(' | listed in MDSGene' if v.listed_in_MDSGene=='yes' else ''),
            f'variant{n}_population_frequency':v.population_frequency,
            f'variant{n}_clinvar_id':int(v.clinvar_id) if v.clinvar_id!='' else 'not in ClinVar'}
# ---------- per-variant genotype summaries from published cases ----------
CAi=CA.set_index('case_id')
rows=[]
for v in VT.itertuples(index=False):
    vid=v.variant_id; lk=LK[LK.variant_id==vid]; cases=CAi.loc[sorted(set(lk.case_id))] if len(lk) else CAi.iloc[0:0]
    nh=(cases.biallelic_status=='biallelic (homozygous)').sum(); nc=(cases.biallelic_status=='biallelic (compound heterozygous)').sum(); nt=(cases.biallelic_status.str.startswith('monoallelic')).sum(); nu=(cases.biallelic_status=='unknown').sum()
    partners={}
    for cid in cases[cases.biallelic_status=='biallelic (compound heterozygous)'].index:
        other=LK[(LK.case_id==cid)&(LK.variant_id!=vid)]
        for o in other.itertuples(): partners[(o.variant_id,o.protein_hgvs or o.allele_as_reported)]=partners.get((o.variant_id,o.protein_hgvs or o.allele_as_reported),0)+1
    seg=(cases.segregation_analysis.str.startswith('affected relatives carry')).sum()
    sib=(cases.siblings_genotype!='').sum()
    bi=cases[cases.biallelic_status.str.startswith('biallelic')]; ages=pd.to_numeric(bi.age_at_onset,errors='coerce').dropna()
    refs=sorted(set('; '.join(cases.source_reference).split('; '))-{''})
    uc=UCA[UCA.variant_ids.str.contains(vid)]; uch=(uc.zygosity.astype(str).str.strip()=='Het').sum(); uchom=(uc.zygosity.astype(str).str.lower().str.startswith(('hom','compound'))).sum()
    gid=v.gnomad_id; src=gi.loc[gid,'Source'] if gid else ''
    filt=gi.loc[gid,'Filters - joint'] if gid else ''; flg=gi.loc[gid,'Flags'] if gid else ''; flg='' if pd.isna(flg) else flg
    yrs=sorted({int(m) for m in re.findall(r'(?:19|20)\d\d','; '.join(refs))})
    # A fields
    A={'genetic_test':('population exome/genome sequencing ('+src.replace('gnomAD ','').replace(',',' + ')+', gnomAD v4.1)' if gid else 'population data: absent from gnomAD')+('; clinical testing (ClinVar submissions)' if v.clinvar_id!='' else '')+(f'; published case reports ({len(cases)} rows)' if len(cases) else ''),
       'sequencing_platform':'Illumina short-read (gnomAD v4.1)' if gid else 'not reported in ClinVar VCF or case compendium',
       'sequencing_center':'; '.join([x for x in ['Broad Institute / gnomAD consortium' if gid else '','ClinVar submitting laboratories (NCBI aggregate)' if v.clinvar_id!='' else '', (f'reporting groups: {refs[0]}'+(f' and {len(refs)-1} others' if len(refs)>1 else '')) if refs else ''] if x]) or 'MDSGene-included study (see MDSGene)',
       'genetic_sample':'germline DNA',
       'sample_id':vid,
       'test_date':'; '.join([x for x in ['gnomAD v4.1 data release 19 Apr 2024' if gid else '', (f'case reports published {min(yrs)}–{max(yrs)}' if yrs else '')] if x]) or 'not reported in source',
       'report_date':'ClinVar release 2026-10-11; gnomAD export 2026-10-16',
       'laboratory_report_id':'; '.join([x for x in [f'ClinVar VCV{int(v.clinvar_id):09d}' if v.clinvar_id!='' else '',f'gnomAD {gid}' if gid else ''] if x]) or 'no database identifier (literature/MDSGene only)',
       'genome_build':'GRCh38','reference_transcript':'NM_032409.3 (MANE Select; ENST00000321556.5)','transcript_version':'NM_032409.3 (RefSeq v3); ENST00000321556.5 (Ensembl v5)',
       'sequencing_method':'exome capture and/or PCR-free whole-genome sequencing, joint-called (gnomAD v4.1)' if gid else 'not reported in source',
       'coverage_mean':(f"depth not in export; allele number {int(gi.loc[gid,'Allele Number']):,} = {gi.loc[gid,'Allele Number']/(2*NIND)*100:.2f}% of individuals called" if gid else 'not assessable (absent from gnomAD; site coverage not checked)'),
       'coverage_gene':GENE_COV,
       'coverage_limitations':('; '.join([x for x in [f'filter {filt}' if filt!='PASS' else 'PASS', f'flag {flg}' if flg else ''] if x]) if gid else 'absent from gnomAD: coverage not checked, absence ≠ rarity'),
       'variant_calling_pipeline':'gnomAD v4.1 joint-calling pipeline (GATK/Hail); ClinVar: per submitting laboratory' if gid else ('per submitting laboratory (not in ClinVar VCF)' if v.clinvar_id!='' else 'as in original publication'),
       'annotation_pipeline':'Ensembl VEP with LOFTEE (gnomAD v4.1; flags v4.1.1); re-harmonised to NM_032409.3 in this study (Python 3.13)',
       'cnv_analysis':('exon-level CNV reported in published patients (method as in original paper)' if 'CNV' in v.variant_type else 'not applicable: short variant; CNVs not captured in ClinVar VCF short-variant records or gnomAD short-variant data'),
       'structural_variant_analysis':'not assessed (gnomAD-SV not queried)'}
    # variant1 = this mutation
    gh=(f'gnomAD homozygotes {v.gnomad_hom}' if gid else 'absent from gnomAD')
    zy=(f'published cases: homozygous {nh}, compound heterozygous {nc}, heterozygous {nt}, zygosity unknown {nu}; {gh}' if len(cases) else f'no published case genotype; {gh}')
    inh=('autosomal recessive (biallelic in published cases)' if nh+nc else ('only heterozygous reports' if nt else 'no published case genotype'))+(f'; segregation with disease reported in {seg} case rows' if seg else '')
    row={'mutation':label(v),'variant_id':vid,'evidence_status':v.evidence_status}
    row.update(A); row.update({'gene':'PINK1','gene_disease_association':v.gene_disease_association})
    row.update(vfields(v,1,zy,inh))
    # variant2 = second allele of the most frequently reported biallelic genotype
    if nh>=max(partners.values(),default=0) and nh>0:
        row.update(vfields(v,2,'homozygous (same allele as variant 1)',inh)); top='homozygous'
    elif partners:
        (pv,pl),cnt=max(partners.items(),key=lambda x:x[1])
        if pv: row.update(vfields(next(VT[VT.variant_id==pv].itertuples(index=False)),2,f'compound heterozygous with variant 1 ({cnt} published cases)','autosomal recessive (compound heterozygous)'))
        else: row.update({f'variant2_{f}':(pl if f=='protein_hgvs' else 'second allele not reported as pathogenic in any source') for f in VF})
        top='compound heterozygous'
    else:
        row.update({f'variant2_{f}':'no biallelic genotype with this variant in published cases' for f in VF}); top=''
    part='; '.join(f'{pl} ×{c}' for (pv,pl),c in sorted(partners.items(),key=lambda x:-x[1])[:5])
    # C fields
    sup=supported(v.evidence_status); disc=v.evidence_status.startswith('Discordant')
    if disc: gds='not confirmed: variant is ClinVar B/LB or above the MCAF'
    elif nh and sup: gds=f'confirmed (provisional): homozygous supported allele in {nh} published case'+('s' if nh>1 else '')
    elif nc and sup and partners and all(supported(VTi.loc[pv].evidence_status) for (pv,_) in partners if pv): gds='probable: compound heterozygous with supported alleles; phase not reported'
    elif nh or nc: gds='probable: biallelic, but allele support incomplete (ClinVar VUS/absent or 0 stars)'
    elif nt: gds='uncertain: only single heterozygous reports'
    else: gds='not assessable: no published case genotype in the compendium'
    rec=[]
    if nc: rec.append('confirm phase by parental testing')
    if nt and not (nh or nc): rec.append('search for second allele (MLPA/CNV, long-read)')
    if 'NMD escape' in v.acmg_criteria_candidates: rec.append('apply PVS1 at reduced strength (NMD escape)')
    if 'splice' in v.variant_type.lower() or 'intron' in str(v.exon_intron): rec.append('RNA study of splicing')
    if v.evidence_status.startswith(('Reported P/LP; not in ClinVar','Reported P/LP; predicted')): rec.append('submit literature evidence to ClinVar')
    if 'VUS' in v.evidence_status: rec.append('reassess with case-level (PM3/PP1) and functional evidence')
    if disc: rec.append('do not count as recessive disease allele without new evidence')
    row.update({'father_genotype':(f'not reported separately; {uch} unaffected heterozygous relatives listed (Yin & Dieriks Suppl. Table 4)' if len(uc) else NR),
        'mother_genotype':(f'not reported separately; {uch} unaffected heterozygous relatives listed (Yin & Dieriks Suppl. Table 4)' if len(uc) else NR),
        'siblings_genotype':(f'affected siblings/relatives carrying the variant reported in {sib} case rows' if sib else NR)+(f'; {uchom} unaffected biallelic relatives listed' if uchom else ''),
        'segregation_analysis':(f'segregation with disease reported in {seg} case rows' if seg else 'no segregation data in compendium'),
        'variant_phase':('homozygous (phase not applicable)' if top=='homozygous' else ('in trans assumed; phase not reported in compendium' if top else 'not applicable')),
        'inheritance_pattern':'autosomal recessive (PARK6)',
        'biallelic_status':f'biallelic in {nh+nc} of {len(cases)} published case rows' + (f' (partners: {part})' if part else ''),
        'second_allele_search':(f'{nt} single-heterozygous case rows; second-allele/CNV testing not reported in compendium' if nt else 'not applicable (no single-heterozygous reports)'),
        'genetic_diagnosis_status':gds,
        'phenotype_consistency':(f'biallelic cases: median onset {ages.median():.0f} y (range {ages.min():.0f}–{ages.max():.0f}; n = {len(ages)}); {(ages<=50).mean()*100:.0f}% ≤50 y' if len(ages) else 'no onset data for biallelic cases'),
        'clinical_interpretation':(f'ClinVar condition: {v.clinvar_condition}; ' if v.clinvar_condition else '')+(f'author claims: {v.literature_evidence.split("claims: ")[1].split("; e.g.")[0]}' if 'claims: ' in v.literature_evidence else 'no author interpretation in compendium'),
        'report_recommendations':'suggested (this analysis): '+('; '.join(rec) if rec else 'none beyond routine confirmation'),
        'wgs_status':('WGS data available (gnomAD genomes)' if 'Genomes' in str(src) else 'no WGS data in sources'),
        'reanalysis_status':'yes: re-annotated on NM_032409.3 and re-evaluated against ClinVar 2026-10-11 and gnomAD v4.1 (this study)',
        'reanalysis_date':'2026-10-20',
        'all_reported_genotypes':(f'homozygous ×{nh}; ' if nh else '')+(f'compound heterozygous with {part}; ' if part else '')+(f'heterozygous ×{nt}' if nt else '') or 'none in compendium',
        'references':'; '.join(refs[:12]) or ('MDSGene' if v.listed_in_MDSGene=='yes' else 'ClinVar / Ma 2021')})
    rows.append(row)
OUT=pd.DataFrame(rows)
cols=['mutation','variant_id','evidence_status']+A_FIELDS+['gene','gene_disease_association']+[f'variant1_{f}' for f in VF]+[f'variant2_{f}' for f in VF]+C_FIELDS+['all_reported_genotypes','references']
OUT=OUT[cols]
# ---------- per-patient sheet: same schema, every cell filled ----------
P=CA.copy()
lab={r.variant_id:label(r) for r in VT.itertuples(index=False)}
P.insert(0,'genotype',[' / '.join(x for x in [lab.get(a,a),lab.get(b,b) if b else ''] if x) or r for a,b,r in zip(P.variant1_id,P.variant2_id,P.alleles_as_reported)])
for f in A_FIELDS: P[f]='not reported in compendium (see original reference)'
P['genome_build']='as in original report (normalised by us to GRCh38)'; P['reference_transcript']='as in original report (normalised by us to NM_032409.3)'
P['transcript_version']='NM_032409.3 (normalised)'; P['genetic_sample']='germline DNA (patient)'; P['sample_id']=P.case_id
P['annotation_pipeline']='re-annotated in this study on NM_032409.3 (ClinVar 2026-10-11, gnomAD v4.1)'
for n in (1,2):
    P[f'variant{n}_allele_balance']=np.where(P[f'variant{n}_protein_hgvs'].astype(str)!='','not reported in compendium','no second variant reported' if n==2 else '')
    P[f'variant{n}_read_depth']=P[f'variant{n}_allele_balance']
    P[f'variant{n}_inheritance']=np.where(P.segregation_analysis.astype(str).str.startswith('affected'),'segregates with disease in family (as reported)','parental origin not reported')
for f in VF:
    c='variant2_'+f; P[c]=P[c].replace('', 'no second variant reported (single heterozygous or zygosity unknown)')
for f in C_FIELDS+['siblings_genotype']:
    P[f]=P[f].replace('',NR)
P['father_genotype']=NR; P['mother_genotype']=NR; P['second_allele_search']=np.where(P.biallelic_status.str.startswith('monoallelic'),'not reported in compendium','not applicable (biallelic)')
P['report_recommendations']=np.where(P.variant_phase.str.startswith('not reported'),'confirm phase by parental testing',np.where(P.biallelic_status.str.startswith('monoallelic'),'search for second allele (MLPA/CNV, long-read)','none beyond routine confirmation'))
P['wgs_status']='not reported in compendium'; P['reanalysis_status']='yes: re-annotated in this study'; P['reanalysis_date']='2026-10-20'
P=P.replace('',NR)
pcols=['genotype','case_id','source_reference','compendium_row']+A_FIELDS+['gene','gene_disease_association']+[f'variant1_{f}' for f in VF]+[f'variant2_{f}' for f in VF]+C_FIELDS+['certainty_level_provisional','age_at_onset','sex','ethnicity','family_history','consanguinity','alleles_as_reported','possible_duplicate']
P=P[pcols]
OUT.to_pickle(SP+'OUT.pkl'); P.to_pickle(SP+'P.pkl')
print(OUT.shape,P.shape); print((OUT=='').sum().sum(),'empty cells in variant table;',(P=='').sum().sum(),'in patient table')
print(OUT[['mutation','variant1_zygosity','variant2_protein_hgvs','genetic_diagnosis_status']].head(8).to_string())
