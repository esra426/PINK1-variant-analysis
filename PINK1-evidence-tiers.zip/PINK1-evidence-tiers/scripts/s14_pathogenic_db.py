"""Build the PINK1 pathogenic-variant database (variant, case, case-variant, carrier and dictionary sheets)
from ClinVar (11 Oct 2026), gnomAD v4.1, Ma 2021, Broadway 2022, Yin & Dieriks 2025 and MDSGene."""
import pandas as pd, numpy as np, re, json
U='data/raw/'
SP='out/intermediate/'
cv=pd.read_csv('data/clinvar_final.csv'); g=pd.read_pickle('data/gnomad_final.pkl'); cons=np.loadtxt('data/conservation.txt')
ex=pd.read_csv('data/exon_map.csv').reset_index(drop=True); ex['exon']=ex.index+1
S8=pd.read_excel('data/derived/PINK1_Supporting_Tables_S1-S13.xlsx',sheet_name='S8_Variant_evidence')
DIS='Parkinson disease 6, autosomal recessive early-onset (PARK6; OMIM #605909)'
A3={'A':'Ala','R':'Arg','N':'Asn','D':'Asp','C':'Cys','E':'Glu','Q':'Gln','G':'Gly','H':'His','I':'Ile','L':'Leu','K':'Lys','M':'Met','F':'Phe','P':'Pro','S':'Ser','T':'Thr','W':'Trp','Y':'Tyr','V':'Val','X':'Ter','*':'Ter'}
DOM=[('MTS',1,34),('N-terminal linker',35,93),('transmembrane',94,110),('N-terminal regulatory',111,155),('kinase domain',156,511),('C-terminal domain',512,581)]
CAT={'glycine-rich loop':range(162,171),'VAIK Lys219':[219],'Ser228':[228],'HRD loop':range(360,363),'activation segment':range(384,418)}
MCAF=0.005
def norm_p(x):
    """literature/MDSGene protein notation -> HGVS-like 3-letter key (or None)."""
    s=str(x).strip().replace('∗','*').replace('p.','').strip('()')
    s=re.sub(r'\s.*$','',s)
    m=re.match(r'^([A-Z])(\d+)([A-Z*X=])$',s)
    if m and m.group(1) in A3:
        a,b,c=m.groups(); return f'p.{A3[a]}{b}=' if c in ('=',a) else f'p.{A3[a]}{b}{A3.get(c,c)}'
    m=re.match(r'^([A-Z][a-z]{2})(\d+)([A-Z][a-z]{2}|Ter|\*|X|=)$',s)
    if m: a,b,c=m.groups(); return f'p.{a}{b}' + ('=' if c=='=' or c==a else ('Ter' if c in ('*','X') else c))
    m=re.match(r'^([A-Z])(\d+)([A-Z]?)fs(?:X|\*|Ter)?(\d*)$',s)
    if m and m.group(1) in A3:
        a,b,c,d=m.groups(); return f'p.{A3[a]}{b}' + (A3[c] if c else '') + 'fs' + (f'Ter{d}' if d else '')
    m=re.match(r'^([A-Z][a-z]{2})(\d+)([A-Z][a-z]{2})?fs(?:\*|X|Ter)?(\d*)$',s)
    if m: a,b,c,d=m.groups(); return f'p.{a}{b}'+(c or '')+'fs'+(f'Ter{d}' if d else '')
    return None
def fs_codon(p):
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+).*fs',str(p)); return int(m.group(1)) if m else None
def aa_of(p):
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)',str(p)); return int(m.group(1)) if m else None
def region_of(aa,ctype):
    if aa is None or pd.isna(aa): return ctype or ''
    d=next((n for n,s,e in DOM if s<=aa<=e),'')
    c=next((n for n,v in CAT.items() if aa in v),'')
    return d+(f' ({c})' if c else '')
def exon_of_c(c):
    """exon/intron label from a c. HGVS string."""
    s=str(c)
    m=re.match(r'c\.\*',s)
    if m: return 'exon 8 (3′UTR)'
    m=re.match(r'c\.-(\d+)([+-]\d+)?',s)
    if m: return 'exon 1 (5′UTR)' if not m.group(2) else 'upstream / 5′ region'
    m=re.match(r'c\.(\d+)([+-])(\d+)',s)
    if m:
        n,sg=int(m.group(1)),m.group(2); e=ex[(ex.cs<=n)&(ex.ce>=n)].exon
        if len(e): k=int(e.iloc[0]); return f'intron {k}' if sg=='+' else f'intron {k-1}'
    m=re.match(r'c\.(\d+)',s)
    if m:
        n=int(m.group(1)); e=ex[(ex.cs<=n)&(ex.ce>=n)].exon
        if len(e): return f'exon {int(e.iloc[0])}'
    return ''
def c_from_vcf(r):
    """c. HGVS for ClinVar records absent from gnomAD (SNVs exact; indels described from VCF alleles)."""
    if pd.isna(r.c_pos): return ''
    c=int(r.c_pos); loc=str(r.c_loc)
    if len(r.ref)==1 and len(r.alt)==1:
        if loc=='exonic':
            if c<1: return f'c.-{1-c}{r.ref}>{r.alt}'
            if c>1746: return f'c.*{c-1746}{r.ref}>{r.alt}'
            return f'c.{c}{r.ref}>{r.alt}'
        m=re.match(r'intron([+-]\d+)',loc)
        if m: return f'c.{c}{m.group(1)}{r.ref}>{r.alt}'
    m=re.match(r'NC_000001\.11:g\.(\d+)(?:_(\d+))?(del|dup|ins[ACGT]+|delins[ACGT]+)$',str(r.hgvs_g))
    if m:
        def g2c(x):
            x=int(x); e=ex[(ex['gs']<=x)&(ex['ge']>=x)]
            return int(x-e.off.iloc[0]) if len(e) else None
        a=g2c(m.group(1)); b=g2c(m.group(2)) if m.group(2) else None
        if a and 1<=a<=1746 and (m.group(2) is None or (b and b<=1746)):
            return f'c.{a}' + (f'_{b}' if b else '') + m.group(3)
    return ''  # otherwise the genomic HGVS is given
# ---------- functional evidence ----------
ma={}
for l in open('data/raw/ma2021.txt'):
    if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l):
        parts=re.split(r'\s{2,}',l.strip()); ma[parts[0]]=parts[4]
S11=pd.read_excel('data/derived/PINK1_Supporting_Tables_S1-S13.xlsx',sheet_name='S11_T3_additions')
import json as _j
T=_j.load(open('data/derived/tables_ahg.json'))
fx={}  # protein -> list of functional statements
for k,v in ma.items(): fx.setdefault(k,[]).append(f'Ma 2021: {v} (Sherloc + parkin recruitment/mitophagy)')
for row in T['t8'][1:]:
    p='p.'+row[0].strip('p.()');
    if row[1].startswith('Broadway'): fx.setdefault(p,[]).append(f'Broadway 2022: {row[2]}')
for r in S11.itertuples():
    if str(r.source).startswith('Broadway'): fx.setdefault(r.variant,[]).append(f'Broadway 2022: {r.result} ({r.assay})')
for k in fx: fx[k]=sorted(set(fx[k]))
# ---------- literature compendium ----------
L=pd.read_excel(U+'sj-xlsx-2-pkn-10.1177_1877718x241304814.xlsx'); L['row']=np.arange(1,len(L)+1)
UC=pd.read_excel(U+'sj-xlsx-4-pkn-10.1177_1877718x241304814.xlsx',sheet_name=None)
lit_claim=L['Reported pathogenicity (from reference)'].fillna('').astype(str).str.strip().str.lower()
L['claim_P']=lit_claim.str.startswith(('pathogenic','likely pathogenic'))
def cite(ref):
    out=[]
    for part in str(ref).split(';'):
        m=re.match(r'\s*(.+?,\s*)((?:19|20)\d\d)',part)
        out.append((m.group(1)+m.group(2)).strip() if m else part.strip())
    return '; '.join(out)
def split_alleles(s):
    s=str(s); parts=[x.strip() for x in s.split('/') if x.strip()]
    return parts
# ---------- MDSGene ----------
mtxt=open('data/raw/MDSGene_PINK1_overview.txt').read()
mds_tokens=set(re.findall(r'p\.[A-Z][a-z]{2}\d+[A-Za-z0-9_*]+',mtxt))
mds_keys={norm_p(t) or t.replace('*','Ter') for t in mds_tokens}
mds_c=set(t for t in re.findall(r'c\.[\(\)\d\?_\+\-]+[A-Za-z>]*[ACGT]*del|c\.[\(\)\d\?_\+\-]+dup|c\.\d+[+-]\d+[ACGT]>[ACGT]|c\.\d+-\d+_\d+del',mtxt))
# ---------- gnomAD index ----------
gp=g[g['Protein Consequence'].notna()].copy()
gidx={p:r for p,r in zip(gp['Protein Consequence'],gp.itertuples())}
gkey={r.key:r for r in g.itertuples()}
def gnomad_fields(key=None,p=None):
    r=gkey.get(key) if key else None
    if r is None and p: r=gidx.get(p)
    if r is None: return dict(gnomad_id='',gnomad_AC='',gnomad_AN='',gnomad_AF='',gnomad_FAF='',gnomad_FAF_group='',gnomad_hom='',gnomad_filter='',
                              population_frequency='absent from gnomAD v4.1 (site coverage not assessed)')
    faf=getattr(r,'_29') if False else r[ list(g.columns).index('GroupMax FAF frequency')+1 ]
    grp=r[list(g.columns).index('GroupMax FAF group')+1]; AF=r[list(g.columns).index('Allele Frequency')+1]
    AC=r[list(g.columns).index('Allele Count')+1]; AN=r[list(g.columns).index('Allele Number')+1]; hom=r[list(g.columns).index('Homozygote Count')+1]
    flt=r[list(g.columns).index('Filters - joint')+1]; gid=r[list(g.columns).index('gnomAD ID')+1]
    s=f'AF {AF:.2e} ({int(AC)}/{int(AN)}); GroupMax FAF {faf:.2e} ({grp})' if pd.notna(faf) else f'AF {AF:.2e} ({int(AC)}/{int(AN)}); GroupMax FAF not available'
    s+=f'; homozygotes {int(hom)}; filter {flt}'
    return dict(gnomad_id=gid,gnomad_AC=int(AC),gnomad_AN=int(AN),gnomad_AF=float(AF),gnomad_FAF=(float(faf) if pd.notna(faf) else ''),gnomad_FAF_group=grp if pd.notna(grp) else '',
                gnomad_hom=int(hom),gnomad_filter=flt,population_frequency=s)
# ---------- master variant list ----------
V={}  # key -> dict
def vkey(p=None,c=None,desc=None): return p or c or desc
cvp=cv.copy(); cvp['p_norm']=cvp.p
S8i=S8.set_index('ClinVar VariationID')
def add(key,**kw):
    d=V.setdefault(key,dict(sources=set(),lit_rows=[],mds=False))
    for k,v in kw.items():
        if k=='sources': d['sources']|=v
        elif v not in (None,'') and not (isinstance(v,float) and np.isnan(v)): d.setdefault(k,v)
    return d
# 1 ClinVar P/LP
for r in cv[cv.cls=='P/LP'].itertuples():
    s8=S8i.loc[r.cv_id]; cdna=s8['HGVS c. (ENST00000321556.5/NM_032409.3)'] if pd.notna(s8['HGVS c. (ENST00000321556.5/NM_032409.3)']) else c_from_vcf(r)
    key=vkey(r.p if pd.notna(r.p) else None, cdna or None, f'ClinVar {r.cv_id}')
    if key in V and V[key].get('clinvar_id') not in (None,int(r.cv_id)): key=f'{key}|{cdna}'
    add(key,sources={'ClinVar P/LP'},clinvar_id=int(r.cv_id),genomic_hgvs=r.hgvs_g,cDNA_hgvs=cdna,protein_hgvs=(r.p if pd.notna(r.p) else ''),
        vtype=r.vtype,clinvar_class=r.clnsig,stars=int(r.stars),revstat=r.revstat,condition=r.dn,gkey=r.key,aa=r.aa)
# 2 Ma 2021 P/LP
for p,cl in ma.items():
    if cl.lower().startswith(('pathogenic','likely pathogenic')): add(p,sources={'Ma 2021 P/LP'},protein_hgvs=p,vtype='Missense')
# 3 literature-reported P/LP and 4 MDSGene
ALIAS={'534_535insQ':'p.Gln534dup','p.Gln534_Ser535insGln':'p.Gln534dup','L485_R497del':'p.Leu485_Arg497del','R58_V59insGR':'p.Arg58_Val59insGlyArg'}
def cnv_key(raw):
    s=str(raw)
    m=re.search(r'exons?\s*(\d+)(?:\s*-\s*(\d+))?\s*(del|dup)',s,re.I)
    if m:
        a,b,t=m.groups(); return f'CNV: exon{"s" if b else ""} {a}{"–"+b if b else ""} {"deletion" if t.lower()=="del" else "duplication"}'
    m=re.match(r'c\.\((\?|\d+\+1)_(-?\d+)(?:-1)?\)_\((\d+)\+1_\d+-1\)(del|dup)',s)
    if m:
        st=m.group(2); st=1 if st.startswith('-') else int(st); en=int(m.group(3))
        e1=ex[ex.cs==st].exon; e2=ex[ex.ce==en].exon
        if len(e1) and len(e2):
            a,b=int(e1.iloc[0]),int(e2.iloc[0]); t=m.group(4)
            return f'CNV: exon{"s" if a!=b else ""} {a}{"–"+str(b) if a!=b else ""} {"deletion" if t=="del" else "duplication"}'
    return None
def ivs_c(raw):
    m=re.search(r'IVS(\d+)([+-])(\d+)([ACGT])>([ACGT])',str(raw))
    if not m: return None
    n,sg,k,a,b=m.groups(); n=int(n)
    base=int(ex.ce[ex.exon==n].iloc[0]) if sg=='+' else int(ex.cs[ex.exon==n+1].iloc[0])
    return f'c.{base}{sg}{k}{a}>{b}'
def lit_key(raw):
    s0=str(raw).strip()
    if s0 in ALIAS: return ALIAS[s0]
    k=norm_p(raw)
    if k: return ALIAS.get(k,k)
    k=cnv_key(raw) or ivs_c(raw)
    if k: return k
    s=str(raw).strip()
    m=re.search(r'c\.\s*[-\d+*_]+\s*[ACGT]?\s*>?\s*[ACGT]?',s)
    if m: return re.sub(r'\s','',m.group(0))
    return 'literature: '+s
for r in L.itertuples():
    for a in split_alleles(r._1):
        k=lit_key(a)
        if r.claim_P: add(k,sources={'Literature-reported P/LP'})
mds_keys={ALIAS.get(k,k) for k in mds_keys}|{cnv_key(c) for c in mds_c if cnv_key(c)}|{c for c in mds_c if re.match(r'c\.\d+[+-]\d+[ACGT]>[ACGT]$',c)}
for k in mds_keys:
    add(k,sources={'MDSGene (listed in included patients)'},protein_hgvs=k if k.startswith('p.') else '')
    V[k]['mds']=True
# frameshift harmonisation: literature short forms (p.Gln129fsTer157) -> ClinVar/gnomAD frameshift at same codon
fs_full={fs_codon(p):p for p in list(cv[cv.p.fillna('').str.contains('fs')].p)+list(gp[gp['Protein Consequence'].str.contains('fs')]['Protein Consequence'])}
for k in list(V):
    if k.startswith('p.') and 'fs' in k:
        c=fs_codon(k); full=fs_full.get(c)
        if full and full!=k:
            d=V.pop(k); t=V.setdefault(full,dict(sources=set(),lit_rows=[],mds=False)); t['sources']|=d['sources']; t['lit_rows']+=d['lit_rows']; t['mds']|=d['mds']
            t.setdefault('alias',set()).add(k)
# attach literature rows to final variant keys (after alias and frameshift harmonisation)
resolve={k:k for k in V}
for k,d in V.items():
    for al in d.get('alias',[]): resolve[al]=k
for k in list(resolve):
    if k.startswith('p.') and 'fs' in k and k not in V: resolve[k]=fs_full.get(fs_codon(k),k)
for r in L.itertuples():
    for a in split_alleles(r._1):
        k=lit_key(a)
        if k and 'fs' in k and k not in resolve: k=fs_full.get(fs_codon(k),k)
        k=resolve.get(k,k)
        if k in V: V[k]['lit_rows'].append(r.row)
# complete annotation from ClinVar (any class) and gnomAD
cv_by_p={r.p:r for r in cv.itertuples() if pd.notna(r.p)}
cv_by_c={}
for r in cv.itertuples():
    cc=S8i.loc[r.cv_id]['HGVS c. (ENST00000321556.5/NM_032409.3)']
    cc=cc if pd.notna(cc) else c_from_vcf(r)
    if cc: cv_by_c[cc]=r
g_by_c={tc:r for tc,r in zip(g['Transcript Consequence'],g.itertuples()) if isinstance(tc,str)}
rows=[]
for k,d in V.items():
    p=d.get('protein_hgvs') or (k if k.startswith('p.') else '')
    if k.startswith('c.') and not d.get('cDNA_hgvs'): d['cDNA_hgvs']=k
    c=cv_by_p.get(p) if p else (cv_by_c.get(k) if k.startswith('c.') else None)
    if c is None and k.startswith('c.') and k in g_by_c: d.setdefault('gkey',g_by_c[k].key); d.setdefault('cDNA_hgvs',k)
    if c is not None and 'clinvar_id' not in d:
        s8=S8i.loc[c.cv_id]; cd=s8['HGVS c. (ENST00000321556.5/NM_032409.3)'] if pd.notna(s8['HGVS c. (ENST00000321556.5/NM_032409.3)']) else c_from_vcf(c)
        d.update(clinvar_id=int(c.cv_id),genomic_hgvs=c.hgvs_g,cDNA_hgvs=cd,vtype=c.vtype,clinvar_class=c.clnsig,stars=int(c.stars),revstat=c.revstat,condition=c.dn,gkey=c.key,aa=c.aa)
    gf=gnomad_fields(d.get('gkey'),p)
    if not d.get('cDNA_hgvs') and gf['gnomad_id']:
        gr=gkey.get(gf['gnomad_id'].replace('chr',''))
    if not d.get('cDNA_hgvs') and p in gidx: d['cDNA_hgvs']=gidx[p][list(g.columns).index('Transcript Consequence')+1]
    if not d.get('genomic_hgvs') and gf['gnomad_id']:
        ch,pos,ref,alt=gf['gnomad_id'].split('-'); d['genomic_hgvs']=f'NC_000001.11:g.{pos}{ref}>{alt}' if len(ref)==1 and len(alt)==1 else f'GRCh38 {gf["gnomad_id"]} (VCF representation)'
    if not d.get('vtype') and p in gidx:
        d['vtype']={'missense_variant':'Missense','stop_gained':'Nonsense','frameshift_variant':'Frameshift','synonymous_variant':'Synonymous','splice_donor_variant':'Canonical splice','splice_acceptor_variant':'Canonical splice','inframe_deletion':'In-frame indel','inframe_insertion':'In-frame indel'}.get(gidx[p][list(g.columns).index('VEP Annotation')+1],'')
    if not d.get('vtype'):
        d['vtype']='Frameshift' if 'fs' in k else ('Nonsense' if k.endswith('Ter') else ('Missense' if re.match(r'p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}$',k) else ('Splice/intronic' if re.match(r'c\.\d+[+-]',k) else ('In-frame indel' if re.search(r'del|ins|dup',k) and k.startswith('p.') else ('CNV (exon-level)' if k.startswith('CNV') else 'Other / as reported')))))
    aa=d.get('aa') if pd.notna(d.get('aa',np.nan)) else aa_of(p)
    aa=int(aa) if aa is not None and not (isinstance(aa,float) and np.isnan(aa)) else None
    exi=exon_of_c(d.get('cDNA_hgvs','')) or (next((f'exon {int(e)}' for e,s,t in zip(ex.exon,(ex.cs+2)//3,(ex.ce+2)//3) if aa and s<=aa<=t),'') if aa else '')
    reg=region_of(aa,'') if aa else ('splice region / intron' if 'intron' in exi else ('5′UTR' if '5′' in exi else ('3′UTR' if '3′' in exi else '')))
    lr=L[L.row.isin(d['lit_rows'])]; z=lr.Zygosity.fillna('').str.strip().str.lower()
    nh=int(z.str.startswith('hom').sum()); nc=int(z.str.startswith('compound').sum()); nt=int((z=='het').sum())
    seg=int((lr['Affected family carry same variant'].fillna('').astype(str).str.startswith('Y')&z.str.startswith(('hom','compound'))).sum())
    claims=sorted(set(lr['Reported pathogenicity (from reference)'].dropna().astype(str).str.strip()))
    refs=list(lr.Reference.dropna().astype(str).map(cite).value_counts().index[:4])
    litev=(f'{len(lr)} published case rows (homozygous {nh}, compound heterozygous {nc}, heterozygous {nt}); claims: {"; ".join(claims)}; e.g. {"; ".join(refs)}' if len(lr) else 'not in Yin & Dieriks compendium')
    # candidate ACMG criteria (research use)
    crit=[]; vt=d['vtype']; faf=gf['gnomad_FAF']
    ptc=None
    if vt=='Nonsense' and d.get('cDNA_hgvs','').startswith('c.'):
        m=re.match(r'c\.(\d+)',d['cDNA_hgvs']); ptc=int(m.group(1)) if m else None
    if vt=='Nonsense' and ptc is None and aa: ptc=3*aa
    if vt=='Frameshift':
        m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',p); ptc=3*(int(m.group(1))+int(m.group(2))-1) if m else None
    if vt in ('Nonsense','Frameshift'):
        crit.append('PVS1 (NMD predicted)' if ptc and ptc<=1438 else ('PVS1 at reduced strength (predicted NMD escape)' if ptc else 'PVS1 candidate (PTC position not resolved)'))
    if vt=='Canonical splice' or re.match(r'c\.\d+[+-][12][ACGT]>',str(d.get('cDNA_hgvs',''))): crit.append('PVS1 candidate (canonical splice; RNA effect not tested)')
    if vt in ('Large/CNV','CNV (exon-level)') and re.search(r'del|exon',k,re.I): crit.append('PVS1 candidate (deletion; extent to confirm)')
    if faf!='' and faf>=0.05: crit.append('BA1 (GroupMax FAF ≥0.05)')
    elif faf!='' and faf>MCAF: crit.append('BS1 candidate (GroupMax FAF > MCAF 0.0050)')
    elif gf['gnomad_id']=='' : crit.append('PM2 not applied (absent from gnomAD; coverage not assessed)')
    else: crit.append('frequency below MCAF (compatible with PM2_Supporting if coverage adequate)')
    fxs=fx.get(p,[])
    if any(('Loss of function' in s) or ('Pathogenic' in s and 'Ma' in s) or ('Reduced' in s) or ('Intermediate' in s) for s in fxs): crit.append('PS3 candidate (damaging functional result; assay not calibrated)')
    if any(('Normal' in s) or ('Benign' in s and 'Ma' in s) for s in fxs): crit.append('BS3 candidate (normal functional result; assay not calibrated)')
    freq_benign=(faf!='' and faf>MCAF)
    if freq_benign and nh+nc+seg>0: crit.append('case-level criteria (PM3/PP1) not applied: frequency criterion met')
    if nh+nc>0 and not freq_benign: crit.append(f'PM3 candidate ({nh} homozygous / {nc} compound heterozygous case rows; phase and independence not verified)')
    if seg>0 and not freq_benign: crit.append(f'PP1 candidate (segregation of a biallelic genotype reported in {seg} case rows)')
    rv=S8i.loc[d['clinvar_id']] if d.get('clinvar_id') in S8i.index else None
    if rv is not None and pd.notna(rv.get('revel_max',np.nan)):
        x=rv['revel_max']; crit.append('PP3_Moderate (REVEL ≥0.773)' if x>=0.773 else 'PP3_Supporting (REVEL ≥0.644)' if x>=0.644 else 'BP4 (REVEL ≤0.290)' if x<=0.290 else 'REVEL indeterminate')
    flags=[]
    cls=str(d.get('clinvar_class',''))
    if 'benign' in cls.lower() and 'conflicting' not in cls.lower(): flags.append('ClinVar B/LB')
    if 'Conflicting' in cls: flags.append('ClinVar conflicting')
    if 'Uncertain' in cls: flags.append('ClinVar VUS')
    if faf!='' and faf>MCAF: flags.append('above MCAF')
    if d.get('stars')==0: flags.append('ClinVar 0 stars')
    cl=cls.lower(); srcs=d['sources']
    if ('benign' in cl and 'conflicting' not in cl) or (faf!='' and faf>MCAF): est='Discordant: reported P/LP but ClinVar B/LB or above MCAF'
    elif 'ClinVar P/LP' in srcs and (d.get('stars') or 0)>=1: est='Supported: ClinVar P/LP (≥1 star)'
    elif 'ClinVar P/LP' in srcs: est='ClinVar P/LP without assertion criteria (0 stars)'
    elif 'uncertain' in cl or 'conflicting' in cl: est='Reported P/LP; ClinVar VUS or conflicting'
    elif vt in ('Nonsense','Frameshift','Canonical splice') or k.startswith('CNV'): est='Reported P/LP; predicted null allele, not in ClinVar as P/LP'
    else: est='Reported P/LP; not in ClinVar'
    nuc=L[L.row.isin(d['lit_rows'])&~L['Amino acid change'].astype(str).str.contains('/')]['Nucleotide change'].dropna().astype(str).str.strip()
    nuc_rep='; '.join(sorted(set(nuc))[:3])
    if d.get('clinvar_id')==2412:
        k='CNV: deletion including exons 6–8 (ClinVar 2412)'; exi='exons 6–8'; vt='CNV (exon-level)'
    rows.append(dict(variant_id='',evidence_status=est,cDNA_as_reported=nuc_rep,gene='PINK1',gene_disease_association=DIS,genomic_hgvs=d.get('genomic_hgvs',''),cDNA_hgvs=d.get('cDNA_hgvs',''),
        protein_hgvs=p.replace('p.','p.(')+')' if p else '',variant_label=k if not k.startswith('p.') else '',aliases='; '.join(sorted(d.get('alias',[]))),
        variant_type=vt,exon_intron=exi,region=reg,
        pathogenic_sources='; '.join(sorted(d['sources'])),n_sources=len(d['sources']),
        classification=cls.replace('_',' ') if cls else 'not in ClinVar',review_stars=d.get('stars',''),review_status=str(d.get('revstat','')).replace('_',' '),
        classification_date='as of ClinVar release 2026-10-11 (last-evaluated date not in VCF)' if cls else '',
        classification_source='ClinVar aggregate (CLNSIG)' if cls else 'literature / Ma 2021 / MDSGene only',
        clinvar_condition=str(d.get('condition','')).replace('_',' '),acmg_criteria_candidates='; '.join(crit),functional_evidence=' | '.join(fxs),
        literature_evidence=litev,listed_in_MDSGene='yes' if d['mds'] else '',**gf,clinvar_id=d.get('clinvar_id',''),review_flags='; '.join(flags),
        conservation=(round(float(cons[aa-1]),3) if aa and 1<=aa<=581 else ''),_aa=aa or 9999,_key=k))
VT=pd.DataFrame(rows)
VT=VT.sort_values(['_aa','cDNA_hgvs','_key']).reset_index(drop=True); VT['variant_id']=[f'PV{i+1:03d}' for i in range(len(VT))]
key2id=dict(zip(VT._key,VT.variant_id))
for k,d in V.items():
    for a in d.get('alias',[]): key2id[a]=key2id.get(k)
VT.to_pickle(SP+'VT.pkl'); json.dump(key2id,open(SP+'key2id.json','w'))
print(len(VT),'variants'); print(VT.pathogenic_sources.value_counts().head(12).to_string()); print(VT.variant_type.value_counts().to_dict())
print(VT[VT['review_flags']!=''][['protein_hgvs','variant_label','pathogenic_sources','classification','review_flags']].head(30).to_string())
