"""Reviewer checks: independent control for regional tests, cis-overlap bound for T3, T1 homozygotes, unresolved annotations, CLNDN rule."""
import pandas as pd, numpy as np, re, json
from scipy import stats
rng=np.random.default_rng(11)
cv=pd.read_csv('data/clinvar_final.csv'); g=pd.read_pickle('data/gnomad_final.pkl'); cons=np.loadtxt('data/conservation.txt')
B=pd.read_csv('out/burden_tiers_final.csv'); X={}
ma=[]
for l in open('data/raw/ma2021.txt'):
    if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l):
        parts=re.split(r'\s{2,}',l.strip())
        if parts[4].lower().startswith(('pathogenic','likely pathogenic')): ma.append(parts[0])
cvm=sorted(set(cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')].p.dropna())); union=sorted(set(cvm)|set(ma))
mis=g[(g['VEP Annotation']=='missense_variant')&g.aa_pos.notna()]
plp_keys=set(cv[cv.cls=='P/LP'].key)
ctrl_old=mis[~mis.key.isin(plp_keys)]
ctrl_new=mis[~mis.key.isin(plp_keys)&~mis['Protein Consequence'].isin(union)]
X['union_in_gnomad_missense']=sorted(set(mis['Protein Consequence'])&set(union))
X['union_left_in_old_control']=sorted(set(ctrl_old['Protein Consequence'])&set(union))
kin=lambda a:(a>=156)&(a<=511)
for nm,ctrl in [('old',ctrl_old),('independent',ctrl_new)]:
    gk=int(kin(ctrl.aa_pos).sum()); gn=len(ctrl); res={'gnomad_n':gn,'gnomad_kinase':gk}
    for k,L in [('ClinVar',cvm),('Ma',sorted(set(ma))),('Union',union)]:
        aa=np.array([int(re.search(r'(\d+)',x).group(1)) for x in L]); kk=int(kin(aa).sum()); n=len(aa)
        o,p=stats.fisher_exact([[kk,n-kk],[gk,gn-gk]]); res[k]=dict(n=n,kinase=kk,OR=round(o,2),p=float(p))
    # catalytic elements
    SITES=[range(162,171),[219],[228],range(360,363),range(384,418)]; core=set(); [core.update(s) for s in SITES]
    P=np.array([int(re.search(r'(\d+)',x).group(1)) for x in union]); Pk=P[kin(P)]
    Gk=ctrl.aa_pos.astype(int).values; Gk=Gk[kin(Gk)]
    a=int(np.isin(Pk,list(core)).sum()); b=int(np.isin(Gk,list(core)).sum())
    o,p=stats.fisher_exact([[a,len(Pk)-a],[b,len(Gk)-b]]); res['core']=dict(plp=f'{a}/{len(Pk)}',gnomad=f'{b}/{len(Gk)}',OR=round(o,2),p=float(p))
    cl=np.array(sorted(core)); dist=lambda v: np.abs(v[:,None]-cl[None,:]).min(1)
    obs=dist(Pk).mean(); null=np.array([dist(rng.choice(Gk,len(Pk),replace=False)).mean() for _ in range(10000)])
    hc=Gk[cons[Gk-1]>=0.95]; null3=np.array([dist(rng.choice(hc,len(Pk),replace=False)).mean() for _ in range(10000)])
    res['perm']=dict(obs=round(float(obs),1),null=round(float(null.mean()),1),p=float(((null<=obs).sum()+1)/10001),p_hc=float(((null3<=obs).sum()+1)/10001),hc_n=int(len(hc)))
    X['regional_'+nm]=res
# cis-overlap bound for T3a/T3: if the less frequent of the two common assay-impaired alleles were always in cis with the other
o=lambda s:B[(B.set==s)&(B.population=='Overall')].iloc[0]
af=lambda pc: float((g[(g['Protein Consequence']==pc)&(g['Filters - joint']=='PASS')]['Allele Count']/g[(g['Protein Consequence']==pc)&(g['Filters - joint']=='PASS')]['Allele Number']).sum())
m318,a339=af('p.Met318Leu'),af('p.Ala339Thr')
for s in ['T3a','T3']:
    q=o(s).q; qmin=q-min(m318,a339)
    X['cis_'+s]=dict(q=q,af_M318L=m318,af_A339T=a339,bi_full=q*q*1e6,bi_cis_bound=qmin*qmin*1e6,fold_vs_T2_bound=qmin*qmin/(o('T2b').q**2))
X['T2_bi']=o('T2b').biallelic_per_million
# T1 homozygotes, current T1 definition
cv['pd_related']=cv.dn.fillna('').str.lower().str.contains('parkinson|pink1')
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','Amish','South Asian','Remaining']
tt=g[g.key.isin(T1.key)&(g['Filters - joint']=='PASS')]
E=sum(((r[f'Allele Number {p}']/2)*(r[f'Allele Count {p}']/r[f'Allele Number {p}'])**2) for _,r in tt.iterrows() for p in POPS if r[f'Allele Number {p}']>0)
Ob=int(sum(tt[f'Homozygote Count {p}'].sum() for p in POPS))
X['T1_hom']=dict(obs=Ob,exp=round(E,4),p=float(stats.poisson.sf(Ob-1,E)),vars=tt[tt['Homozygote Count']>0]['Protein Consequence'].tolist())
# CLNDN rule and excluded P/LP
plp=cv[cv.cls=='P/LP']; X['PLP_excluded_condition']=plp[~plp.pd_related][['cv_id','p','dn','stars']].to_dict('records')
X['PLP_zero_star']=plp[plp.stars<1][['cv_id','p','vtype']].to_dict('records')
# frameshift P/LP without resolvable PTC
fs=cv[(cv.cls=='P/LP')&(cv.vtype=='Frameshift')]
X['fs_unresolved']=fs[~fs.p.fillna('').str.contains('fsTer')][['cv_id','p','in_gnomad','stars','hgvs_g']].to_dict('records')
json.dump(X,open('out/review_checks.json','w'),indent=1,default=str); print(json.dumps(X,indent=1,default=str))
