import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
D='data/';O='out/';F='figures/'
X=pd.read_excel(O+'PINK1_open_data_results.xlsx',sheet_name=None); cv=pd.read_csv(D+'clinvar_final.csv'); g=pd.read_pickle(D+'gnomad_final.pkl'); cons=np.loadtxt(D+'conservation.txt')
C1,C2,C3,C4,C5,GR='#eb6834','#2a78d6','#1baf7a','#eda100','#6250d6','#9a9a9a'
# Fig1
L=X['ClinVar_landscape'].set_index('vtype').drop('All').drop(columns='All')
order=['Missense','Intronic/splice-region','Synonymous','UTR','Frameshift','Nonsense','Canonical splice','In-frame indel','Large/CNV','Other/unannotated'][::-1]
fig,ax=plt.subplots(figsize=(6.3,3.2)); left=np.zeros(len(order))
for c,col,lab in [('P/LP',C1,'P/LP'),('Conflicting',C4,'Conflicting'),('VUS',C2,'VUS'),('B/LB',C3,'B/LB'),('Other',GR,'Other')]:
    v=np.array([L.loc[o,c] if o in L.index else 0 for o in order]); ax.barh(order,v,left=left,color=col,label=lab,edgecolor='white',linewidth=1); left+=v
for i,t in enumerate(left): ax.text(t+2,i,int(t),va='center',fontsize=8)
ax.set_xlabel('ClinVar records (n=477)'); ax.legend(ncol=5,frameon=False,loc='lower center',bbox_to_anchor=(0.4,1.0),fontsize=8); fig.tight_layout(); fig.savefig(F+'fig1.png',dpi=220)
# Fig2 protein map
fig,(a0,a1,a2)=plt.subplots(3,1,figsize=(6.5,4.2),sharex=True,gridspec_kw={'height_ratios':[1,2,1.2]})
sm=pd.Series(cons).rolling(9,center=True,min_periods=1).mean(); a0.plot(range(1,582),sm,color='#444',lw=1); a0.set_ylabel('Ortholog\nidentity',fontsize=8); a0.set_ylim(0,1.05)
for n,s,e,col in [('MTS',1,34,'#a9c6dd'),('',35,93,'#d4d8d4'),('TM',94,110,'#9aa7b0'),('NT',111,155,'#d4d8d4'),('Kinase domain',156,511,'#3f7aa8'),('CTD',512,581,'#7fb59d')]:
    a1.add_patch(plt.Rectangle((s,-0.12),e-s+1,0.24,color=col,lw=0)); 
    if n: a1.text((s+e)/2,0,n,ha='center',va='center',fontsize=7,color='white' if n=='Kinase domain' else 'black')
p=cv[(cv.cls=='P/LP')&cv.aa.notna()]
for r in p.itertuples():
    h=0.75 if r.vtype=='Missense' else 0.5; col=C1 if r.vtype=='Missense' else C5
    a1.plot([r.aa,r.aa],[0.12,h],color=col,lw=0.8); a1.scatter(r.aa,h,s=14,color=col,zorder=3)
v=cv[cv.cls.isin(['VUS','Conflicting'])&cv.revel_tier.isin(['PP3_Moderate','PP3_Supporting'])]
for r in v.itertuples(): a1.plot([r.aa,r.aa],[-0.12,-0.6],color=C2,lw=0.8); a1.scatter(r.aa,-0.6,s=14,color=C2,zorder=3)
a1.set_ylim(-0.8,0.95); a1.set_yticks([]); a1.spines['left'].set_visible(False)
from matplotlib.lines import Line2D
a1.legend(handles=[Line2D([],[],marker='o',ls='',color=C1,label='ClinVar P/LP missense'),Line2D([],[],marker='o',ls='',color=C5,label='ClinVar P/LP truncating'),Line2D([],[],marker='o',ls='',color=C2,label='VUS/conflicting, REVEL ≥0.644')],fontsize=7,frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(0.5,1.18))
gm=g[(g['VEP Annotation']=='missense_variant')&g.aa_pos.notna()]; a2.hist(gm.aa_pos,bins=np.arange(1,592,10),color=C3,edgecolor='white',lw=0.5); a2.set_ylabel('gnomAD\nmissense/10 aa',fontsize=8); a2.set_xlabel('PINK1 amino acid position'); a2.set_xlim(0,582)
fig.tight_layout(); fig.savefig(F+'fig2.png',dpi=220)
# Fig3 carrier
Cc=X['Carrier_freq_by_ancestry']; pops=['Overall','East Asian','Admixed American','Remaining','Middle Eastern','South Asian','African/African American','European (non-Finnish)','European (Finnish)','Ashkenazi Jewish'][::-1]
fig,ax=plt.subplots(figsize=(6.3,3.2)); y=np.arange(len(pops))
for k,(st,col,off) in enumerate([('P/LP + HC pLoF',C1,0.2),('ClinVar P/LP',C2,-0.2)]):
    vals=[Cc[(Cc.set==st)&(Cc.population==p)].carrier_freq.iloc[0]*1000 for p in pops]; ax.barh(y+off,vals,0.38,color=col,label=st)
    if k==0:
        for i,p in enumerate(pops): r=Cc[(Cc.set==st)&(Cc.population==p)].iloc[0]; ax.text(vals[i]+0.05,y[i]+off,f'1/{int(round(r.carrier_1_in))}',va='center',fontsize=7)
ax.set_yticks(y,pops); ax.set_xlabel('Heterozygous carrier frequency (per 1,000)'); ax.legend(frameon=False,fontsize=8,loc='lower right'); fig.tight_layout(); fig.savefig(F+'fig3.png',dpi=220)
# Fig4 REVEL
mis=cv[(cv.vtype=='Missense')&cv.revel_max.notna()]; rng=np.random.default_rng(1)
fig,ax=plt.subplots(figsize=(6.3,2.4))
for i,(lab,col,d) in enumerate([('B/LB',C3,mis[mis.cls=='B/LB']),('VUS/conflicting',C2,mis[mis.cls.isin(['VUS','Conflicting'])]),('P/LP',C1,mis[mis.cls=='P/LP'])]):
    ax.scatter(d.revel_max,i+rng.uniform(-.25,.25,len(d)),s=12,color=col,alpha=.7); ax.text(-0.02,i,f'{lab} (n={len(d)})',ha='right',va='center',fontsize=8)
for t in [0.183,0.290,0.644,0.773,0.932]: ax.axvline(t,color='#999',ls='--',lw=0.7)
ax.set_yticks([]); ax.spines['left'].set_visible(False); ax.set_xlim(0,1); ax.set_xlabel('REVEL score (dashed: ClinGen-calibrated BP4/PP3 thresholds)'); fig.tight_layout(); fig.savefig(F+'fig4.png',dpi=220)
# Fig5 AAO
lit=pd.read_excel('data/raw/sj-xlsx-2-pkn-10.1177_1877718x241304814.xlsx')
lit['aao']=pd.to_numeric(lit['Age at onset/diagnosis'],errors='coerce'); z=lit.Zygosity.fillna('').astype(str).str.strip()
bi=z.str.lower().str.startswith(('hom','compound')); rp=lit['Reported pathogenicity (from reference)'].fillna('').astype(str).str.lower().str.startswith(('pathogenic','likely pathogenic'))
common={'A340T','N521T','E476K','Q115L','D391D'}
A=lit[bi].aao.dropna(); B=lit[(z=='Het')&rp&~lit['Amino acid change'].astype(str).str.strip().isin(common)].aao.dropna()
fig,ax=plt.subplots(figsize=(6.3,2.2)); ax.boxplot([B,A],vert=False,widths=.5,showfliers=False,medianprops=dict(color='k',lw=2))
for i,(d,col) in enumerate([(B,C2),(A,C1)]): ax.scatter(d,i+1+rng.uniform(-.18,.18,len(d)),s=8,color=col,alpha=.5)
ax.set_yticks([1,2],[f'Heterozygous P/LP\n(n={len(B)})',f'Biallelic\n(n={len(A)})']); ax.set_xlabel('Age at onset/diagnosis (years)'); fig.tight_layout(); fig.savefig(F+'fig5.png',dpi=220)
print('ok',len(A),len(B))
