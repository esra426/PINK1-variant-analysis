"""Rebuild manuscript Table 2 (burden by ancestry), Table 3 (sensitivity) and key text values from out/burden_tiers_final.csv."""
import pandas as pd, numpy as np, re, json, sys
base=sys.argv[1] if len(sys.argv)>1 else '.'
cv=pd.read_csv(f'{base}/data/clinvar_final.csv'); g=pd.read_pickle(f'{base}/data/gnomad_final.pkl'); B=pd.read_csv(f'{base}/out/burden_tiers_final.csv')
cv['pd_related']=cv.dn.fillna('').str.lower().str.contains('parkinson|pink1')
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]
def ptc(p,v,c):
    if v=='stop_gained': return c
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',str(p)); return 3*(int(m.group(1))+int(m.group(2))-1) if m else np.nan
g['c_num']=g['Transcript Consequence'].str.extract(r'c\.(\d+)')[0].astype(float)
g['ptc']=[ptc(p,v,c) for p,v,c in zip(g['Protein Consequence'],g['VEP Annotation'],g.c_num)]
blb=set(cv[cv.cls=='B/LB'].key); ok=~g.Flags.fillna('').str.contains('lof_flag|lcr')&~g.key.isin(blb)
nmd=g['VEP Annotation'].isin(['stop_gained','frameshift_variant'])&(g.ptc<=1438)&ok
spl=g['VEP Annotation'].isin(['splice_acceptor_variant','splice_donor_variant'])&ok
P=g['Filters - joint']=='PASS'
K={'T1_selected':len(T1),'T1_included':int((g.key.isin(T1.key)&P).sum()),'T1_absent':int((~T1.key.isin(g.key)).sum()),
   'T1_filtered':int((g.key.isin(T1.key)&~P).sum()),'T2_selected':len(set(T1.key)|set(g.key[nmd|spl])),'n_splice_T2':int((spl&P).sum())}
POPS=['Overall','African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','South Asian','Remaining']
def r(s,p): return B[(B.set==s)&(B.population==p)].iloc[0]
c=lambda x:f'{int(round(x)):,}'
def qci(x): return f"{x.q*1e4:.2f} ({x.q_lo*1e4:.2f}–{x.q_hi*1e4:.2f})"+('†' if x.ci_method.startswith('exact') else '')
def bi(x): return f"{x.biallelic_per_million:.2f} ({x.biallelic_lo:.2f}–{x.biallelic_hi:.2f})"
def car(x): return c(x.carrier_1_in) if x.AC>0 else f"none observed (≥1 in {c(1/(2*x.q_hi*(1-x.q_hi)))})"
burden=[['Ancestry group','T1 variants included / AC','T1 q ×10⁻⁴ (95% CI)','T1 carriers, 1 in','T2 variants included / AC','T2 q ×10⁻⁴ (95% CI)','T2 carriers, 1 in','T2 expected biallelic per 10⁶ (95% CI)']]
for p in POPS:
    a,b=r('T1',p),r('T2b',p)
    burden.append([p,f'{a.variants_included} / {a.AC}',qci(a),car(a),f'{b.variants_included} / {b.AC}',qci(b),car(b),bi(b)])
lab=[('T1','T1: ClinVar-supported P/LP (≥1 star, PD-related)'),('T1 minus predicted NMD-escape','T1 without 6 predicted NMD-escape alleles'),
 ('T2a','T2 restricted to NMD-predicted nonsense/frameshift (no splice)'),('T2b','T2: T1 + NMD-predicted truncating + canonical splice'),
 ('T2b minus p.Arg492Ter','T2 without p.(Arg492Ter)'),('T3a','T3a: T2 + 4 assay-impaired VUS (Broadway et al., 2022; stress test)'),
 ('T3b','T3b: T2 + 7 variants P/LP on combined evidence (Ma et al., 2021; stress test)'),('T3','T3: T2 + all 11 (union; stress test)')]
sens=[['Allele set','Variants included†','AC','q ×10⁻⁴ (95% CI)','Carriers, 1 in','Expected biallelic per 10⁶ (95% CI)']]
for s,l in lab:
    x=r(s,'Overall'); sens.append([l,str(x.variants_included),str(x.AC),f"{x.q*1e4:.2f} ({x.q_lo*1e4:.2f}–{x.q_hi*1e4:.2f})",c(x.carrier_1_in),bi(x)])
o=lambda s:r(s,'Overall')
K.update({'fold_T3a_T2':o('T3a').biallelic_per_million/o('T2b').biallelic_per_million,'fold_T3_T2':o('T3').biallelic_per_million/o('T2b').biallelic_per_million,
 'fold_T3_T1':o('T3').biallelic_per_million/o('T1').biallelic_per_million,'T1_1_in_million':1/o('T1').biallelic_per_million,'T2_1_in_million':1/o('T2b').biallelic_per_million})
json.dump({'burden':burden,'sens':sens,'K':K},open(f'{base}/out/tables_update.json','w'),ensure_ascii=False,indent=0)
print(json.dumps(K,indent=0))
