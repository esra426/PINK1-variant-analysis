import pandas as pd, numpy as np, json, re
rng=np.random.default_rng(7)
cv=pd.read_csv('data/clinvar_final.csv'); g=pd.read_pickle('data/gnomad_final.pkl')
X={}
X['clinvar_records']=len(cv); X['clinvar_unique_keys']=int(cv.key.nunique()); X['clinvar_unique_ids']=int(cv.cv_id.nunique())
cv['pd_related']=cv.dn.fillna('').str.lower().str.contains('parkinson|pink1')
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]; t1k=set(T1.key)
passk=set(g[g['Filters - joint']=='PASS'].key)
X['T1_in_gnomad_pass']=len(t1k&passk); X['T1_in_gnomad_any']=len(t1k&set(g.key)); X['T1_absent']=len(t1k-set(g.key))
# rebuild tiers as in s6
def nmd_c(p,v,c):
    if v=='stop_gained': return c
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',str(p))
    return 3*(int(m.group(1))+int(m.group(2))-1) if m else np.nan
g['c_num']=g['Transcript Consequence'].str.extract(r'c\.(\d+)')[0].astype(float)
g['ptc']=[nmd_c(p,v,c) for p,v,c in zip(g['Protein Consequence'],g['VEP Annotation'],g.c_num)]
blb=set(cv[cv.cls=='B/LB'].key)
trunc=g['VEP Annotation'].isin(['stop_gained','frameshift_variant'])
lof=(trunc&(g.ptc<=1438))|g['VEP Annotation'].isin(['splice_acceptor_variant','splice_donor_variant'])
lof=lof&~g.Flags.fillna('').str.contains('lof_flag|lcr')&~g.key.isin(blb)
fd=['p.Met318Leu','p.Val418Met','p.Ala339Thr','p.Asp525Asn','p.Ser419Pro','p.Glu240Lys','p.Leu369Pro','p.Gly386Ala','p.Pro416Leu','p.Leu489Pro','p.Gly409Arg','p.Ile368Asn']
P=g['Filters - joint']=='PASS'
esc=set(T1[T1.p.isin(['p.Tyr444MetfsTer39','p.Tyr466LeufsTer49','p.Arg492Ter','p.Arg501Ter','p.Lys520ArgfsTer3','p.Gln534Ter'])].key)
sets={'T1':g.key.isin(t1k),'T2':g.key.isin(t1k)|lof,'T3':g.key.isin(t1k)|lof|g['Protein Consequence'].isin(fd),
      'T1 minus predicted NMD-escape':g.key.isin(t1k-esc),'T2 minus most frequent allele':None,'T2 excluding conflicting':None}
conf=set(cv[cv.cls=='Conflicting'].key)
t2=g[sets['T2']&P]; top=t2.sort_values('Allele Count').key.iloc[-1]; X['T2_top_allele']=t2.set_index('key').loc[top,'Protein Consequence']
sets['T2 minus most frequent allele']=sets['T2']&(g.key!=top); sets['T2 excluding conflicting']=sets['T2']&~g.key.isin(conf)
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','South Asian','Remaining']
rows=[]
for nm,s in sets.items():
    sub=g[s&P]
    for pop in ['Overall']+POPS:
        ac=(sub['Allele Count'] if pop=='Overall' else sub[f'Allele Count {pop}']).values.astype(float)
        an=(sub['Allele Number'] if pop=='Overall' else sub[f'Allele Number {pop}']).values.astype(float)
        ok=an>0; ac,an=ac[ok],an[ok]
        q=(ac/an).sum()
        # parametric bootstrap: AC_i ~ Poisson(AC_i); zero-count variants contribute upper bound via Poisson(0.5) not used
        bs=(rng.poisson(ac,(10000,len(ac)))/an).sum(1) if len(ac) else np.zeros(1)
        lo,hi=np.percentile(bs,[2.5,97.5])
        rows.append(dict(set=nm,population=pop,variants=int((ac>0).sum()),AC=int(ac.sum()),q=q,q_lo=lo,q_hi=hi,
            carrier_per_100k=2*q*(1-q)*1e5,carrier_1_in=(1/(2*q*(1-q)) if q>0 else np.inf),
            biallelic_per_million=q*q*1e6,biallelic_lo=lo*lo*1e6,biallelic_hi=hi*hi*1e6))
B=pd.DataFrame(rows); B.to_csv('out/burden_final.csv',index=False)
# MCAF alternative
K=5e-5; a=0.5; f=0.5
X['mcaf_primary']=a*np.sqrt(K/f); X['mcaf_alt_inside']=np.sqrt(K*a/f)
faf={'p.Gly30Arg':0.010447,'p.Glu55=':0.005008,'p.Ala494Val':0.005208}
X['bs1_under_alt']=[k for k,v in faf.items() if v>X['mcaf_alt_inside']]
json.dump(X,open('out/final_extra.json','w'),indent=1,default=str)
print(X)
print(B[B.population.isin(['Overall','East Asian','Admixed American','Middle Eastern'])].round(6).to_string(index=False))
