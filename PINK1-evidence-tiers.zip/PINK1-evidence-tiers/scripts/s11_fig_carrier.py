"""Figure 2 (AHG numbering): heterozygous carrier frequency of T1 and T2 alleles by ancestry, 95% CI (delta method / exact Poisson)."""
import pandas as pd, numpy as np, sys, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
base=sys.argv[1]; out=sys.argv[2]
B=pd.read_csv(f'{base}/out/burden_tiers_final.csv')
pops=['Overall','African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','South Asian','Remaining']
cf=lambda q:2*q*(1-q)*1000
fig,ax=plt.subplots(figsize=(6.3,3.8)); y=np.arange(len(pops))[::-1]
for st,col,off,lab in [('T2b','#eb6834',0.2,'T2: T1 + NMD-predicted truncating + canonical splice'),('T1','#2a78d6',-0.2,'T1: ClinVar-supported P/LP')]:
    d=B[B.set==st].set_index('population').loc[pops]
    v=cf(d.q.values); lo=cf(d.q_lo.clip(lower=0).values); hi=cf(d.q_hi.values)
    ax.barh(y+off,v,0.38,color=col,label=lab)
    ax.errorbar(v,y+off,xerr=[v-lo,hi-v],fmt='none',ecolor='#333333',elinewidth=0.9,capsize=2.5)
ax.set_yticks(y,pops); ax.set_xlim(0,None); ax.set_xlabel('Heterozygous carrier frequency per 1,000 (95% CI)')
h,l=ax.get_legend_handles_labels(); ax.legend(h[::-1],l[::-1],frameon=False,fontsize=8,loc='lower center',bbox_to_anchor=(0.4,1.0),ncol=1)
fig.tight_layout(); fig.savefig(out,dpi=300)
