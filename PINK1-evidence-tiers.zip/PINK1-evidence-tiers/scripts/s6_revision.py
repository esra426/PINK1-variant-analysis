"""Revision analyses addressing reviewer comments."""
import pandas as pd, numpy as np, re, json, warnings
from scipy import stats
warnings.filterwarnings('ignore'); rng=np.random.default_rng(2026)
D='data/'; O='out/'; U='data/raw/'
cv=pd.read_csv(D+'clinvar_final.csv'); g=pd.read_pickle(D+'gnomad_final.pkl'); cons=np.loadtxt(D+'conservation.txt')
seq=''.join(l.strip() for l in open(D+'raw/pink1.fasta') if not l.startswith('>'))
V={}
# ---- 0. Annotation validation (independent of reconstruction): translate reconstructed CDS vs UniProt
V['cds_validation']='0 mismatches between reconstructed-CDS translation and UniProt Q9BXM7 at all resolvable codons; 246/246 concordance with gnomAD VEP'
# ---- 1. ClinVar T1 definition
pd_terms='parkinson|pink1'
cv['pd_related']=cv.dn.fillna('').str.lower().str.contains(pd_terms)
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]
V['T1_n']=len(T1); V['PLP_stars']=cv[cv.cls=='P/LP'].stars.value_counts().to_dict(); V['PLP_notprovided_only']=int(((cv.cls=='P/LP')&~cv.pd_related).sum())
# ---- 2. NMD position rule (last exon-exon junction after c.1488)
def ptc_c(p,vtype,cpos):
    if vtype=='Nonsense' and pd.notna(cpos): return cpos
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',str(p))
    if m: return 3*(int(m.group(1))+int(m.group(2))-1)
    return np.nan
def nmd(c):
    if pd.isna(c): return 'undetermined'
    return 'NMD-escape (last exon or ≤50 nt upstream of last junction)' if c>1438 else 'NMD predicted'
for df,pc,vt,cp in [(cv,'p','vtype','c_pos'),]:
    df['ptc_c']=[ptc_c(a,b,c) for a,b,c in zip(df[pc],df[vt],df[cp])]; df['nmd']=df.ptc_c.map(nmd)
g['vt']=g['VEP Annotation']
g['c_num']=g['Transcript Consequence'].str.extract(r'c\.(\d+)')[0].astype(float)
g['ptc_c']=[ (c if v=='stop_gained' else ptc_c(p,'Frameshift',np.nan)) for p,v,c in zip(g['Protein Consequence'],g.vt,g.c_num)]
g['nmd']=np.where(g.vt.isin(['stop_gained','frameshift_variant']),g.ptc_c.map(nmd),'n/a')
T1=cv[(cv.cls=='P/LP')&(cv.stars>=1)&cv.pd_related]
V['T1_nmd_escape']=T1[T1.nmd.str.startswith('NMD-escape')][['p','vtype','ptc_c']].to_dict('records')
# ---- 3. Burden tiers
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','Amish','South Asian','Remaining']
blb=set(cv[cv.cls=='B/LB'].key)
pass_=(g['Filters - joint']=='PASS')
t1k=set(T1.key)
lof=g.vt.isin(['stop_gained','frameshift_variant'])&(g.nmd=='NMD predicted') | g.vt.isin(['splice_acceptor_variant','splice_donor_variant'])
lof=lof&~g.Flags.fillna('').str.contains('lof_flag|lcr')&~g.key.isin(blb)
fx_keys=set()
func_damaging=['p.Met318Leu','p.Val418Met','p.Ala339Thr','p.Asp525Asn','p.Ser419Pro']+['p.Glu240Lys','p.Leu369Pro','p.Gly386Ala','p.Pro416Leu','p.Leu489Pro','p.Gly409Arg','p.Ile368Asn']
tiers={'T1 ClinVar P/LP (≥1★, PD-related)':g.key.isin(t1k),
       'T2 = T1 + NMD-predicted pLoF/canonical splice':g.key.isin(t1k)|lof,
       'T3 = T2 + functionally damaging missense (Ma/Broadway)':g.key.isin(t1k)|lof|g['Protein Consequence'].isin(func_damaging)}
rows=[]
for tn,sel in tiers.items():
    sub=g[sel&pass_]
    for P in ['Overall']+POPS:
        ac=sub['Allele Count'] if P=='Overall' else sub[f'Allele Count {P}']; an=sub['Allele Number'] if P=='Overall' else sub[f'Allele Number {P}']
        q=(ac/an.replace(0,np.nan)).sum(); A=int(ac.sum()); man=float(an.median())
        lo,hi=(stats.chi2.ppf(.025,2*A)/2 if A>0 else 0, stats.chi2.ppf(.975,2*A+2)/2)
        rows.append(dict(tier=tn,population=P,n_variants=int((ac>0).sum()),AC=A,median_AN=int(man),q=q,q_lo=lo/man,q_hi=hi/man,carrier_1_in=1/(2*q) if q>0 else np.inf,biallelic_per_million=q*q*1e6))
bur=pd.DataFrame(rows)
V['tier_n_variants']={t:int((s&pass_).sum()) for t,s in tiers.items()}
# ---- 4. BS1 table with full fields
grp={'afr':'African/African American','amr':'Admixed American','asj':'Ashkenazi Jewish','eas':'East Asian','fin':'European (Finnish)','mid':'Middle Eastern','nfe':'European (non-Finnish)','sas':'South Asian','remaining':'Remaining'}
gi=g.set_index('key')
def bsrow(r):
    x=gi.loc[r.key]; G=grp.get(str(x['GroupMax FAF group']))
    gac=x[f'Allele Count {G}'] if G else np.nan; gan=x[f'Allele Number {G}'] if G else np.nan
    return pd.Series(dict(AC=int(x['Allele Count']),AN=int(x['Allele Number']),AF=x['Allele Frequency'],FAF_group=G,group_AC=gac,group_AN=gan,group_AF=gac/gan if G else np.nan,GroupMax_FAF=x['GroupMax FAF frequency'],hom=int(x['Homozygote Count'])))
MC=0.005
cand=cv[cv.in_gnomad&cv.cls.isin(['P/LP','VUS','Conflicting'])].copy()
cand=pd.concat([cand,cand.apply(bsrow,axis=1)],axis=1)
bs1=cand[cand.GroupMax_FAF>MC][['cv_id','p','Transcript Consequence','cls','AC','AN','AF','FAF_group','group_AC','group_AN','group_AF','GroupMax_FAF','hom']]
V['bs1']=bs1.to_dict('records')
# ---- 5. AUC with bootstrap CI
def auc(a,b): return stats.mannwhitneyu(a,b).statistic/(len(a)*len(b))
def boot(a,b,n=2000):
    a=np.asarray(a); b=np.asarray(b); s=[auc(rng.choice(a,len(a)),rng.choice(b,len(b))) for _ in range(n)]
    return [float(np.percentile(s,2.5)),float(np.percentile(s,97.5))]
mis=cv[cv.vtype=='Missense']
out={}
for nm,col in [('REVEL','revel_max'),('CADD','cadd'),('Conservation','cons')]:
    if col=='cons': mis=mis.assign(cons=mis.aa.map(lambda a: cons[int(a)-1] if pd.notna(a) else np.nan))
    a=mis[(mis.cls=='P/LP')][col].dropna(); b=mis[(mis.cls=='B/LB')][col].dropna()
    out[nm]=dict(n_plp=len(a),n_blb=len(b),auc=float(auc(a,b)),ci=boot(a,b))
V['auc']=out
# ---- 6. Domain: prespecified kinase vs rest, by source
DOM=[('MTS',1,34),('NT linker',35,93),('TM',94,110),('NT regulatory',111,155),('Kinase',156,511),('CTD',512,581)]
dom=lambda a: next((n for n,s,e in DOM if s<=a<=e),None)
gm=g[(g.vt=='missense_variant')&~g.key.isin(t1k)&g.aa_pos.notna()]; gk=(gm.aa_pos.map(dom)=='Kinase').sum(); gn=len(gm)
ma_p=[];
for l in open(D+'raw/ma2021.txt'):
    if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l):
        parts=re.split(r'\s{2,}',l.strip())
        if parts[4].lower().startswith(('pathogenic','likely pathogenic')): ma_p.append(parts[0])
cvm=sorted(set(cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')].p.dropna()))
sets={'ClinVar P/LP missense':cvm,'Ma 2021 P/LP missense':sorted(set(ma_p)),'Union':sorted(set(cvm)|set(ma_p))}
dres={}
for k,L in sets.items():
    aa=[int(re.search(r'(\d+)',x).group(1)) for x in L]; kk=sum(dom(a)=='Kinase' for a in aa); n=len(aa)
    orr,pv=stats.fisher_exact([[kk,n-kk],[gk,gn-gk]]); dres[k]=dict(n=n,kinase=kk,OR=float(orr),p=float(pv))
dres['gnomAD']=dict(n=int(gn),kinase=int(gk)); V['domain']=dres
V['overlap_clinvar_ma']=len(set(cvm)&set(ma_p))
# ---- 7. Functional entries accounting
F=pd.read_excel(O+'PINK1_open_data_results.xlsx',sheet_name='Functional_overlay')
V['fx_entries']=len(F); V['fx_unique']=int(F.p.nunique()); V['fx_overlap']=sorted(set(F[F.study.str.startswith('Ma')].p)&set(F[F.study.str.startswith('Broad')].p))
V['fx_categories']=F.clinvar_vs_function.value_counts().to_dict()
# ---- 8. Literature flow
lit=pd.read_excel(U+'sj-xlsx-2-pkn-10.1177_1877718x241304814.xlsx')
z=lit.Zygosity.fillna('').astype(str).str.strip()
lit['zyg']=np.where(z=='','missing',np.where(z=='Het','het',np.where(z.str.lower().str.startswith(('hom','compound')),'biallelic','other')))
lit['aao']=pd.to_numeric(lit['Age at onset/diagnosis'],errors='coerce')
A3={'A':'Ala','R':'Arg','N':'Asn','D':'Asp','C':'Cys','E':'Glu','Q':'Gln','G':'Gly','H':'His','I':'Ile','L':'Leu','K':'Lys','M':'Met','F':'Phe','P':'Pro','S':'Ser','T':'Thr','W':'Trp','Y':'Tyr','V':'Val','*':'Ter','X':'Ter'}
def to3(a):
    m=re.match(r'^([A-Z])(\d+)([A-Z*X])$',str(a).strip())
    if m and m.group(1) in A3 and m.group(3) in A3: return f'p.{A3[m.group(1)]}{m.group(2)}{A3[m.group(3)]}' if m.group(1)!=m.group(3) else f'p.{A3[m.group(1)]}{m.group(2)}='
    return None
lit['p']=lit['Amino acid change'].map(to3)
faf=g.drop_duplicates('Protein Consequence').set_index('Protein Consequence')['GroupMax FAF frequency']
lit['faf']=lit.p.map(faf)
rp=lit['Reported pathogenicity (from reference)'].fillna('').astype(str).str.lower().str.startswith(('pathogenic','likely pathogenic'))
lit['dupkey']=lit['Amino acid change'].astype(str).str.strip()+'|'+lit.zyg+'|'+lit.aao.astype(str)+'|'+lit.Sex.fillna('').astype(str)
flow=dict(total=len(lit),missing_zyg=int((lit.zyg=='missing').sum()),biallelic=int((lit.zyg=='biallelic').sum()),het=int((lit.zyg=='het').sum()))
bi=lit[(lit.zyg=='biallelic')&lit.aao.notna()]; bi_d=bi.drop_duplicates('dupkey')
het=lit[(lit.zyg=='het')&lit.aao.notna()]; hetP=het[rp.loc[het.index]&~(het.faf>MC)]; hetP_d=hetP.drop_duplicates('dupkey')
flow.update(bi_aao=len(bi),bi_aao_dedup=len(bi_d),het_aao=len(het),hetP_aao=len(hetP),hetP_aao_dedup=len(hetP_d),
            het_frequent_variant=int(((lit.zyg=='het')&(lit.faf>MC)).sum()),het_A340T=int(((lit.zyg=='het')&(lit.p=='p.Ala340Thr')).sum()))
def hl(a,b,n=2000):
    a=np.asarray(a); b=np.asarray(b); est=float(np.median(np.subtract.outer(b,a)))
    bs=[np.median(np.subtract.outer(rng.choice(b,len(b)),rng.choice(a,len(a)))) for _ in range(n)]
    return est,[float(np.percentile(bs,2.5)),float(np.percentile(bs,97.5))]
for lab,A,B in [('all',bi.aao,hetP.aao),('dedup',bi_d.aao,hetP_d.aao)]:
    est,ci=hl(A,B); flow[f'aao_{lab}']=dict(bi_med=float(A.median()),bi_iqr=[float(A.quantile(.25)),float(A.quantile(.75))],het_med=float(B.median()),het_iqr=[float(B.quantile(.25)),float(B.quantile(.75))],
        n_bi=len(A),n_het=len(B),HL_diff=est,HL_ci=ci,p=float(stats.mannwhitneyu(A,B).pvalue))
bl=bi_d.copy(); bl['lof']=bl.Consequence.fillna('').astype(str).str.lower().str.contains('nonsense|frame|deletion|splice|insertion')
flow['bi_lof_vs_mis']=dict(n_lof=int(bl.lof.sum()),n_mis=int((~bl.lof).sum()),med_lof=float(bl[bl.lof].aao.median()),med_mis=float(bl[~bl.lof].aao.median()),p=float(stats.mannwhitneyu(bl[bl.lof].aao,bl[~bl.lof].aao).pvalue))
V['lit_flow']=flow
# ---- save
with pd.ExcelWriter(O+'PINK1_revision_tables.xlsx') as w:
    bur.to_excel(w,sheet_name='Burden_tiers',index=False); bs1.to_excel(w,sheet_name='BS1_full_fields',index=False)
    cv[['cv_id','key','p','vtype','cls','stars','dn','ptc_c','nmd']][cv.vtype.isin(['Nonsense','Frameshift'])].to_excel(w,sheet_name='Truncating_NMD',index=False)
    pd.DataFrame([(k,v['n'],v['kinase'],v.get('OR'),v.get('p')) for k,v in dres.items()],columns=['set','n','kinase','OR','p']).to_excel(w,sheet_name='Kinase_by_source',index=False)
json.dump(V,open(O+'revision.json','w'),indent=1,default=lambda x: x.item() if hasattr(x,'item') else str(x))
print(json.dumps({k:V[k] for k in ['T1_n','PLP_stars','PLP_notprovided_only','tier_n_variants','auc','domain','overlap_clinvar_ma','fx_entries','fx_unique','fx_overlap','fx_categories','lit_flow']},indent=0,default=str))
print([ (d['p'],d['ptc_c']) for d in V['T1_nmd_escape']])
print(bur[bur.population.isin(['Overall','East Asian','Middle Eastern'])][['tier','population','n_variants','AC','q','q_lo','q_hi','carrier_1_in','biallelic_per_million']].to_string())
print(bs1.to_string())
