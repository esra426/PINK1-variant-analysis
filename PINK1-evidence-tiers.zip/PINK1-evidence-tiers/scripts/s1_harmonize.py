import pandas as pd, numpy as np, re, json
U='data/raw/'
D='data/'
# ---------- gnomAD ----------
g=pd.read_csv(U+'gnomAD_v4.1.2_ENSG00000158828_2026_10_16_16_34_55.csv')
g['key']=g['Chromosome'].astype(str)+'-'+g['Position'].astype(str)+'-'+g['Reference']+'-'+g['Alternate']
# ---------- ClinVar ----------
rows=[]
for l in open(D+'raw/clinvar_pink1_region.vcf'):
    if l.startswith('#'): continue
    c=l.rstrip('\n').split('\t'); info=dict(x.split('=',1) for x in c[7].split(';') if '=' in x)
    gi=info.get('GENEINFO','')
    if 'PINK1:' not in gi: continue
    rows.append(dict(cv_id=int(c[2]),pos=int(c[1]),ref=c[3],alt=c[4],clnsig=info.get('CLNSIG','NA'),
        revstat=info.get('CLNREVSTAT',''),vc=info.get('CLNVC',''),mc=info.get('MC',''),dn=info.get('CLNDN',''),
        hgvs_g=info.get('CLNHGVS',''),rs=info.get('RS','')))
cv=pd.DataFrame(rows); cv['key']='1-'+cv.pos.astype(str)+'-'+cv.ref+'-'+cv.alt
def cls(s):
    s=s.lower()
    if 'conflicting' in s: return 'Conflicting'
    if s.startswith('pathogenic/likely_pathogenic'): return 'P/LP'
    if s.startswith('pathogenic'): return 'P/LP'
    if s.startswith('likely_pathogenic'): return 'P/LP'
    if 'uncertain' in s: return 'VUS'
    if s.startswith('benign') or s.startswith('likely_benign'): return 'B/LB'
    return 'Other'
cv['cls']=cv.clnsig.map(cls)
def stars(r):
    r=r.lower()
    if r=='' or r.startswith('no_'): return 0  # no_assertion_criteria_provided / no_classification_provided = 0 stars
    if 'practice_guideline' in r: return 4
    if 'expert_panel' in r: return 3
    if 'multiple_submitters' in r and 'no_conflicts' in r: return 2
    if 'criteria_provided' in r: return 1
    return 0
cv['stars']=cv.revstat.map(stars)
cv['mc_term']=cv.mc.str.split(',').apply(lambda L:';'.join(sorted({x.split('|')[1] for x in L if '|' in x})) if L!=[''] else '')
# ---------- CDS map from gnomAD canonical transcript ----------
tx=g['Transcript'].mode()[0]
pts=[];bounds=[]
for p,ref,alt,hc in g[['Position','Reference','Alternate','Transcript Consequence']].itertuples(index=False):
    if not isinstance(hc,str): continue
    m=re.match(r'c\.(\d+)([ACGT])>',hc)
    if m and len(ref)==1 and len(alt)==1: pts.append((p,int(m.group(1))))
    m=re.match(r'c\.(\d+)([+-])(\d+)[ACGT]>',hc)
    if m and len(ref)==1 and len(alt)==1:
        n,s,k=int(m.group(1)),m.group(2),int(m.group(3)); bounds.append((p-k if s=='+' else p+k, n))
pts=pd.DataFrame(pts+bounds,columns=['pos','c']).drop_duplicates(); pts['off']=pts.pos-pts.c
ex=pts.groupby('off').agg(gs=('pos','min'),ge=('pos','max'),cs=('c','min'),ce=('c','max'),n=('c','size')).reset_index()
ex=ex[ex.n>=3].sort_values('gs').reset_index(drop=True)
ex['cs']=[1]+list(ex.ce.values[:-1]+1); ex.loc[ex.index[-1],'ce']=1746
ex['gs']=ex.off+ex.cs; ex['ge']=ex.off+ex.ce
ex.to_csv(D+'exon_map.csv',index=False)
def g2c(pos):
    for r in ex.itertuples():
        if r.gs-0<=pos<=r.ge: return r.cs+(pos-r.gs), 'exonic'
    # intronic: nearest exon boundary
    best=None
    for r in ex.itertuples():
        for gp,cc,side in ((r.gs,r.cs,'-'),(r.ge,r.ce,'+')):
            d=pos-gp
            if (side=='+' and d>0) or (side=='-' and d<0):
                if best is None or abs(d)<abs(best[0]): best=(d,cc)
    return (best[1], f'intron{best[0]:+d}') if best else (None,'')
def aa_of(row):
    c,loc=g2c(row.pos)
    if c is None or c>1746 or c<1: return pd.Series({'c_pos':c,'c_loc':loc,'aa_pos':np.nan})
    return pd.Series({'c_pos':c,'c_loc':loc,'aa_pos':(c-1)//3+1 if loc=='exonic' else np.nan})
cv=pd.concat([cv,cv.apply(aa_of,axis=1)],axis=1)
# gnomAD protein position
g['aa_pos']=g['Protein Consequence'].str.extract(r'p\.[A-Z][a-z]{2}(\d+)')[0].astype(float)
g['cv_now']=g.key.map(cv.set_index('key').cls)
cv['in_gnomad']=cv.key.isin(g.key)
m=cv.merge(g[['key','Protein Consequence','Transcript Consequence','VEP Annotation','Allele Count','Allele Number','Allele Frequency','Homozygote Count','GroupMax FAF group','GroupMax FAF frequency','cadd','revel_max','spliceai_ds_max','pangolin_largest_ds','phylop','Flags','Filters - joint']],on='key',how='left')
# check aa map vs gnomAD
chk=m.dropna(subset=['Protein Consequence']).copy(); chk['gaa']=chk['Protein Consequence'].str.extract(r'p\.[A-Z][a-z]{2}(\d+)')[0].astype(float)
chk=chk.dropna(subset=['gaa','aa_pos']); print('aa map concordance',(chk.gaa==chk.aa_pos).mean(),len(chk))
m.to_csv(D+'clinvar_pink1_annot.csv',index=False); g.to_pickle(D+'gnomad.pkl')
print('ClinVar PINK1 records',len(cv)); print(cv.cls.value_counts().to_dict()); print('in gnomAD',cv.in_gnomad.sum())
print(cv.stars.value_counts().to_dict()); print('exons',len(ex)); print(ex.to_string())
print('tx',tx)
