import pandas as pd, numpy as np, re, json, warnings
from scipy import stats
warnings.filterwarnings('ignore')
U='data/raw/'; D='data/'; O='out/'
R={}  # results for report
cv=pd.read_csv(D+'clinvar_pink1_annot.csv'); g=pd.read_pickle(D+'gnomad.pkl'); ex=pd.read_csv(D+'exon_map.csv')
# ---------- protein sequence ----------
seq=''.join(l.strip() for l in open(D+'raw/pink1.fasta') if not l.startswith('>'))
assert len(seq)==581, len(seq)
A3={'A':'Ala','R':'Arg','N':'Asn','D':'Asp','C':'Cys','E':'Glu','Q':'Gln','G':'Gly','H':'His','I':'Ile','L':'Leu','K':'Lys','M':'Met','F':'Phe','P':'Pro','S':'Ser','T':'Thr','W':'Trp','Y':'Tyr','V':'Val','*':'Ter'}
bases='TCAG'; codons=[a+b+c for a in bases for b in bases for c in bases]
aas='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'; CODE=dict(zip(codons,aas))
# ---------- reconstruct CDS from observed reference bases ----------
cds=[None]*1746
def cpos(pos):
    for r in ex.itertuples():
        if r.gs<=pos<=r.ge: return pos-r.off
    return None
for p,ref,alt in g[['Position','Reference','Alternate']].itertuples(index=False):
    for i,b in enumerate(ref):
        c=cpos(p+i)
        if c and 1<=c<=1746: cds[c-1]=b
for p,ref in cv[['pos','ref']].itertuples(index=False):
    for i,b in enumerate(ref):
        c=cpos(p+i)
        if c and 1<=c<=1746: cds[c-1]=b
known=sum(x is not None for x in cds)
# fill gaps per codon using protein sequence (only if unique)
for k in range(582):
    cod=cds[3*k:3*k+3]; aa=seq[k] if k<581 else '*'
    if None in cod:
        opts=[c for c in codons if CODE[c]==aa and all(cod[i] in (None,c[i]) for i in range(3))]
        if len(opts)==1: cds[3*k:3*k+3]=list(opts[0])
R['cds_known_bases']=known; R['cds_after_fill']=sum(x is not None for x in cds)
# validate translation
tr=''.join(CODE.get(''.join(cds[3*k:3*k+3]),'?') if None not in cds[3*k:3*k+3] else '?' for k in range(582))
R['translation_mismatch']=sum(1 for a,b in zip(tr,seq+'*') if a!='?' and a!=b)
def pchange(pos,ref,alt):
    if len(ref)!=1 or len(alt)!=1: return None
    c=cpos(pos)
    if not c or c>1746: return None
    k=(c-1)//3; cod=cds[3*k:3*k+3]
    a0=seq[k] if k<581 else '*'; i=(c-1)%3
    opts=[x for x in codons if CODE[x]==a0 and all(cod[j] in (None,x[j]) for j in range(3))]
    alts={CODE[x[:i]+alt+x[i+1:]] for x in opts}
    if len(alts)!=1: return None
    a1=alts.pop()
    if a0==a1: return f'p.{A3[a0]}{k+1}='
    return f'p.{A3[a0]}{k+1}{A3[a1]}'
cv['p_calc']=[pchange(p,r,a) for p,r,a in cv[['pos','ref','alt']].itertuples(index=False)]
cv['Protein Consequence']=cv['Protein Consequence'].str.replace(r'^(p\.([A-Z][a-z]{2})(\d+))\2$',r'\1=',regex=True)
cv['p']=cv['Protein Consequence'].where(cv['Protein Consequence'].notna(),cv.p_calc)
# manual override: codon 3rd base unresolvable from open files; protein change from ClinVar record title (VCV000002414, VCV000002404)
cv.loc[cv.cv_id==2414,'p']='p.Ala217Asp'; cv.loc[cv.cv_id==2404,'p']='p.Gly309Asp'
ok=cv.dropna(subset=['Protein Consequence','p_calc']); R['p_calc_concordance']=float((ok['Protein Consequence']==ok.p_calc).mean()); R['p_calc_n']=len(ok)
# ---------- variant type ----------
def vtype(r):
    t=str(r.get('VEP Annotation')) if pd.notna(r.get('VEP Annotation')) else ''
    s=(r.mc_term if isinstance(r.mc_term,str) else '')+';'+t
    p=r.p if isinstance(r.p,str) else ''
    if 'nonsense' in s or 'stop_gained' in s or p.endswith('Ter'): return 'Nonsense'
    if 'frameshift' in s: return 'Frameshift'
    if 'splice_donor' in s or 'splice_acceptor' in s: return 'Canonical splice'
    if 'initiator' in s or 'start_lost' in s: return 'Start-loss'
    if 'missense' in s or (p and not p.endswith('=') and re.match(r'p\.([A-Z][a-z]{2})\d+(?!\1)[A-Z][a-z]{2}$',p)): return 'Missense'
    if 'inframe' in s: return 'In-frame indel'
    if 'synonymous' in s or p.endswith('='): return 'Synonymous'
    if 'UTR' in s: return 'UTR'
    if 'intron' in s or 'splice' in s: return 'Intronic/splice-region'
    if r.vc in ('Deletion','Duplication','Insertion','copy_number_loss') and len(str(r.ref))+len(str(r.alt))>50: return 'Large/CNV'
    return 'Other/unannotated'
cv['vtype']=cv.apply(vtype,axis=1)
def aapos(r):
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)',str(r.p))
    return float(m.group(1)) if m else r.aa_pos
cv['aa']=cv.apply(aapos,axis=1)
DOM=[('MTS',1,34),('NT linker',35,93),('TM',94,110),('NT/regulatory',111,155),('Kinase',156,511),('CTD',512,581)]
def dom(a):
    if pd.isna(a): return None
    for n,s,e in DOM:
        if s<=a<=e: return n
g['Protein Consequence']=g['Protein Consequence'].str.replace(r'^(p\.([A-Z][a-z]{2})(\d+))\2$',r'\1=',regex=True)
g['dom']=g.aa_pos.map(dom); cv['dom']=cv.aa.map(dom)
# ---------- 1. ClinVar landscape ----------
land=pd.crosstab(cv.vtype,cv.cls,margins=True); R['clinvar_n']=len(cv); R['cls_counts']=cv.cls.value_counts().to_dict()
R['stars']=cv.stars.value_counts().sort_index().to_dict(); R['clinvar_in_gnomad']=int(cv.in_gnomad.sum())
R['vus_conf_frac']=float(cv.cls.isin(['VUS','Conflicting']).mean())
# ---------- 2. gnomAD & carrier frequency ----------
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','Amish','South Asian','Remaining']
plp_keys=set(cv[cv.cls=='P/LP'].key); blb_keys=set(cv[cv.cls=='B/LB'].key)
lof_types={'stop_gained','frameshift_variant','splice_acceptor_variant','splice_donor_variant','start_lost'}
g['pLoF']=g['VEP Annotation'].isin(lof_types)&(g.aa_pos.fillna(0)<=560)&(~g.Flags.fillna('').str.contains('lof_flag'))
g['set_plp']=g.key.isin(plp_keys)
g['set_union']=g.set_plp|(g.pLoF&~g.key.isin(blb_keys))
g['AF']=g['Allele Frequency']
def carrier(sel,label):
    sub=g[sel&(g['Filters - joint']=='PASS')]; out=[]
    for P in POPS+['Overall']:
        if P=='Overall': ac,an=sub['Allele Count'],sub['Allele Number']
        else: ac,an=sub[f'Allele Count {P}'],sub[f'Allele Number {P}']
        q=(ac/an.replace(0,np.nan)).sum(); tot_ac=int(ac.sum()); man=float(an.median()) if len(an) else np.nan
        lo,hi=stats.poisson.interval(0.95,tot_ac) if tot_ac>0 else (0,3.69)
        out.append(dict(set=label,population=P,variants_observed=int((ac>0).sum()),total_AC=tot_ac,median_AN=man,q=q,
            carrier_freq=2*q*(1-q),carrier_1_in=(1/(2*q) if q>0 else np.inf),biallelic_per_100k=q*q*1e5,
            q_lo=lo/man if man else np.nan,q_hi=hi/man if man else np.nan))
    return pd.DataFrame(out)
car=pd.concat([carrier(g.set_plp,'ClinVar P/LP'),carrier(g.set_union,'P/LP + HC pLoF')])
R['plp_in_gnomad']=int(g.set_plp.sum()); R['union_in_gnomad']=int(g.set_union.sum())
plp_g=g[g.set_plp][['key','Protein Consequence','Transcript Consequence','VEP Annotation','Allele Count','Allele Number','AF','Homozygote Count','GroupMax FAF group','GroupMax FAF frequency']].sort_values('Allele Count',ascending=False)
R['plp_homozygotes']=plp_g[plp_g['Homozygote Count']>0][['Protein Consequence','Transcript Consequence','Allele Count','Homozygote Count']].to_dict('records')
# ---------- 3. Maximum credible AF / BS1 ----------
def mcaf(prev,pen,allelic): return allelic*np.sqrt(prev/pen)
scen={'conservative':dict(prev=1e-2*0.10*0.05,pen=0.5,allelic=0.5),'central':dict(prev=3e-3*0.10*0.03,pen=0.8,allelic=0.3),'strict':dict(prev=1e-3*0.05*0.02,pen=1.0,allelic=0.2)}
R['mcaf']={k:dict(v,mcaf=float(mcaf(**v))) for k,v in scen.items()}
TH=R['mcaf']['conservative']['mcaf']
cv['FAF']=cv['GroupMax FAF frequency']; cv['AF']=cv['Allele Frequency']
cv['BS1_flag']=np.where(cv.FAF>=0.05,'BA1 (FAF≥5%)',np.where(cv.FAF>TH,f'BS1 (FAF>{TH:.4f})',np.where(cv.FAF>R['mcaf']['strict']['mcaf'],'BS1 under strict scenario only','')))
bs1=cv[(cv.BS1_flag!='')&cv.cls.isin(['P/LP','VUS','Conflicting'])][['cv_id','p','Transcript Consequence','vtype','cls','clnsig','stars','AF','FAF','GroupMax FAF group','Homozygote Count','BS1_flag']].sort_values('FAF',ascending=False)
R['bs1_by_cls']={f'{a} | {b}':int(v) for (a,b),v in bs1.groupby(['cls','BS1_flag']).size().items()}
R['pm2_absent']=cv[cv.cls.isin(['VUS','Conflicting'])&~cv.in_gnomad].shape[0]
# ---------- 4. In-silico calibration ----------
mis=cv[(cv.vtype=='Missense')&cv.revel_max.notna()]
pos=mis[mis.cls=='P/LP'].revel_max; neg=mis[mis.cls=='B/LB'].revel_max
def auc(a,b):
    if len(a)==0 or len(b)==0: return np.nan
    return stats.mannwhitneyu(a,b).statistic/(len(a)*len(b))
R['revel']=dict(n_plp=len(pos),n_blb=len(neg),auc=float(auc(pos,neg)),med_plp=float(pos.median()),med_blb=float(neg.median()))
cad=cv[(cv.vtype=='Missense')&cv.cadd.notna()]; R['cadd_auc']=float(auc(cad[cad.cls=='P/LP'].cadd,cad[cad.cls=='B/LB'].cadd))
def revel_tier(x):
    if pd.isna(x): return 'no score'
    if x>=0.932: return 'PP3_Strong'
    if x>=0.773: return 'PP3_Moderate'
    if x>=0.644: return 'PP3_Supporting'
    if x<=0.003: return 'BP4_VeryStrong'
    if x<=0.016: return 'BP4_Strong'
    if x<=0.183: return 'BP4_Moderate'
    if x<=0.290: return 'BP4_Supporting'
    return 'Indeterminate'
cv['revel_tier']=cv.revel_max.map(revel_tier)
def splice_tier(r):
    s=r.spliceai_ds_max
    if pd.isna(s): return 'no score'
    if s>=0.5: return 'PP3 (SpliceAI≥0.5)'
    if s>=0.2: return 'PP3 (SpliceAI≥0.2)'
    if s<=0.1: return 'BP4/BP7-compatible (≤0.1)'
    return 'Indeterminate'
cv['splice_tier']=cv.apply(splice_tier,axis=1)
vusm=cv[cv.cls.isin(['VUS','Conflicting'])&(cv.vtype=='Missense')]
R['vus_missense_n']=len(vusm); R['vus_missense_revel']=vusm.revel_tier.value_counts().to_dict()
R['plp_revel_tier']=cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')].revel_tier.value_counts().to_dict()
R['blb_revel_tier']=cv[(cv.cls=='B/LB')&(cv.vtype=='Missense')].revel_tier.value_counts().to_dict()
vusnc=cv[cv.cls.isin(['VUS','Conflicting'])&cv.vtype.isin(['Synonymous','Intronic/splice-region','UTR'])]
R['vus_noncoding_splice']=vusnc.splice_tier.value_counts().to_dict()
# ---------- 5. Domain distribution ----------
gm=g[(g['VEP Annotation']=='missense_variant')&~g.set_plp]
pm=cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')]
ma_path=[re.search(r'p\.[A-Z][a-z]{2}(\d+)',l).group(1) for l in open(D+'raw/ma2021.txt') if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l) and re.split(r'\s{2,}',l.strip())[4].lower().startswith(('pathogenic','likely pathogenic'))]
ma_p=[re.search(r'p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}',l).group(0) for l in open(D+'raw/ma2021.txt') if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l) and re.split(r'\s{2,}',l.strip())[4].lower().startswith(('pathogenic','likely pathogenic'))]
pu=pd.DataFrame({'p':sorted(set(pm.p.dropna())|set(ma_p))}); pu['aa']=pu.p.str.extract(r'(\d+)')[0].astype(float); pu['dom']=pu.aa.map(dom)
R['plp_union_missense_n']=len(pu); pm=pu
vm=cv[cv.cls.isin(['VUS','Conflicting'])&(cv.vtype=='Missense')]
dt=[]
for n,s,e in DOM:
    L=e-s+1; a=(pm.dom==n).sum(); b=(gm.dom==n).sum(); v=(vm.dom==n).sum()
    dt.append(dict(domain=n,start=s,end=e,length=L,PLP_missense=a,VUS_missense=v,gnomAD_missense=b,PLP_per100aa=100*a/L,gnomAD_per100aa=100*b/L))
dt=pd.DataFrame(dt)
for i,r in dt.iterrows():
    a=r.PLP_missense; b=r.gnomAD_missense; A=dt.PLP_missense.sum()-a; B=dt.gnomAD_missense.sum()-b
    orr,p=stats.fisher_exact([[a,A],[b,B]]); dt.loc[i,'OR_vs_rest']=orr; dt.loc[i,'p_fisher']=p
R['domain']=dt.to_dict('records')
cons=np.loadtxt(D+'conservation.txt'); R['n_orthologs']=433
cv['cons']=cv.aa.map(lambda a: cons[int(a)-1] if pd.notna(a) and 1<=a<=581 else np.nan); g['cons']=g.aa_pos.map(lambda a: cons[int(a)-1] if pd.notna(a) and 1<=a<=581 else np.nan)
cp=cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')].cons.dropna(); cb=cv[(cv.cls=='B/LB')&(cv.vtype=='Missense')].cons.dropna(); cg=g[(g['VEP Annotation']=='missense_variant')&~g.set_plp].cons.dropna()
cvv=cv[cv.cls.isin(['VUS','Conflicting'])&(cv.vtype=='Missense')].cons.dropna()
R['conservation']=dict(plp_median=float(cp.median()),blb_median=float(cb.median()),gnomad_median=float(cg.median()),vus_median=float(cvv.median()),n_plp=len(cp),n_blb=len(cb),auc_plp_vs_blb=float(auc(cp,cb)),p_plp_vs_gnomad=float(stats.mannwhitneyu(cp,cg).pvalue),
  vus_highcons_frac=float((cvv>=0.95).mean()), plp_highcons_frac=float((cp>=0.95).mean()), blb_highcons_frac=float((cb>=0.95).mean()))
# rare gnomAD missense AC>=... gnomAD missense AF distribution in kinase
# ---------- 6. Functional overlay ----------
ma=[l for l in open(D+'raw/ma2021.txt') if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l)]
marows=[]
for l in ma:
    p=re.search(r'p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}',l).group(0)
    parts=re.split(r'\s{2,}',l.strip())
    final=parts[4] if len(parts)>4 else ''
    marows.append(dict(p=p,study='Ma 2021 (npj PD)',functional_class=final.replace('ﬁ','fi'),assay='mKeima mitophagy + Parkin translocation (Sherloc+assays)'))
bw={'Q115L':'Reduced substrate phosphorylation (partial LoF)','A340T':'Normal','N521T':'Normal','R207Q':'Normal','M318L':'Loss of function','A339T':'Intermediate (reduced)','V418M':'Loss of function','R501Q':'Loss of function (no stabilisation)','D525N':'Intermediate (reduced)','C575R':'Normal'}
inv={v:k for k,v in A3.items()}
for k,v in bw.items():
    marows.append(dict(p=f'p.{A3[k[0]]}{k[1:-1]}{A3[k[-1]]}',study='Broadway 2022 (Cells)',functional_class=v,assay='pS65-Ub / autophosphorylation, HEK293 PINK1-KO'))
fx=pd.DataFrame(marows)
def fx_dir(s):
    s=s.lower()
    if 'loss' in s or 'pathogenic' in s and 'likely' not in s: return 'damaging'
    if 'likely pathogenic' in s or 'reduced' in s or 'intermediate' in s: return 'damaging (partial)'
    if 'normal' in s or 'benign' in s: return 'normal'
    return 'indeterminate'
fx['fx_dir']=fx.functional_class.map(fx_dir)
cvp=cv.dropna(subset=['p'])[['p','cv_id','cls','clnsig','stars','AF','FAF','revel_max']].drop_duplicates('p')
gp=g[['Protein Consequence','AF','GroupMax FAF frequency','revel_max','cadd']].rename(columns={'Protein Consequence':'p','AF':'gnomAD_AF','GroupMax FAF frequency':'gnomAD_FAF','revel_max':'REVEL','cadd':'CADD'}).drop_duplicates('p')
fx=fx.merge(cvp,on='p',how='left').merge(gp,on='p',how='left')
def concord(r):
    if pd.isna(r.cls): return 'Not in ClinVar'
    if r.fx_dir.startswith('damaging') and r.cls=='P/LP': return 'Concordant'
    if r.fx_dir=='normal' and r.cls=='B/LB': return 'Concordant'
    if r.cls in ('VUS','Conflicting') and r.fx_dir.startswith('damaging'): return 'PS3 candidate (upgrade)'
    if r.cls in ('VUS','Conflicting') and r.fx_dir=='normal': return 'BS3 candidate (downgrade)'
    if r.cls=='P/LP' and r.fx_dir=='normal': return 'DISCORDANT: P/LP but normal function'
    if r.cls=='B/LB' and r.fx_dir.startswith('damaging'): return 'DISCORDANT: B/LB but damaging'
    return 'Indeterminate'
fx['clinvar_vs_function']=fx.apply(concord,axis=1)
R['fx_summary']=fx.clinvar_vs_function.value_counts().to_dict()
# ---------- 7. Literature compendium (JPD 2024 supplement) ----------
lit=pd.read_excel(U+'sj-xlsx-2-pkn-10.1177_1877718x241304814.xlsx')
lit['zyg']=lit.Zygosity.fillna('').astype(str).str.strip().map(lambda z:'Het' if z=='Het' else ('Biallelic' if z.lower().startswith(('hom','compound')) else 'NA'))
lit['aao']=pd.to_numeric(lit['Age at onset/diagnosis'],errors='coerce')
rp=lit['Reported pathogenicity (from reference)'].fillna('').astype(str).str.lower()
lit['reported_P']=rp.str.startswith(('pathogenic','likely pathogenic'))
def to3(a):
    a=str(a).strip().replace('X','*')
    m=re.match(r'^([A-Z])(\d+)([A-Z*])$',a)
    if m and m.group(1) in A3 and m.group(3) in A3: return f'p.{A3[m.group(1)]}{m.group(2)}{A3[m.group(3)]}' if m.group(1)!=m.group(3) else f'p.{A3[m.group(1)]}{m.group(2)}='
    m=re.match(r'^([A-Z][a-z]{2})(\d+)([A-Z][a-z]{2})$',a)
    if m: return f'p.{a}'
    return None
lit['p']=lit['Amino acid change'].map(to3)
lit=lit.merge(gp,on='p',how='left').merge(cvp[['p','cls']].rename(columns={'cls':'clinvar_cls'}),on='p',how='left')
lit['common_flag']=lit.gnomAD_FAF>TH
aao=lit.dropna(subset=['aao'])
bi=aao[aao.zyg=='Biallelic'].aao; het_p=aao[(aao.zyg=='Het')&aao.reported_P&~aao.common_flag.fillna(False)].aao; het_all=aao[aao.zyg=='Het'].aao
R['lit']=dict(rows=len(lit),biallelic_rows=int((lit.zyg=='Biallelic').sum()),het_rows=int((lit.zyg=='Het').sum()),
    aao_biallelic=dict(n=len(bi),median=float(bi.median()),iqr=[float(bi.quantile(.25)),float(bi.quantile(.75))]),
    aao_het_reportedP=dict(n=len(het_p),median=float(het_p.median()),iqr=[float(het_p.quantile(.25)),float(het_p.quantile(.75))]),
    aao_het_all=dict(n=len(het_all),median=float(het_all.median())),
    mwu_p_biallelic_vs_hetP=float(stats.mannwhitneyu(bi,het_p).pvalue),
    het_rows_common_variant=int(((lit.zyg=='Het')&lit.common_flag.fillna(False)).sum()),
    pct_aao_le50_biallelic=float((bi<=50).mean()),pct_aao_le50_hetP=float((het_p<=50).mean()))
# biallelic: LoF-containing vs missense-only (by row consequence)
bl=aao[aao.zyg=='Biallelic'].copy(); bl['lof']=bl.Consequence.fillna('').astype(str).str.lower().str.contains('nonsense|frame|deletion|splice|insertion')
R['lit']['aao_bi_lof']=dict(n=int(bl.lof.sum()),median=float(bl[bl.lof].aao.median())); R['lit']['aao_bi_mis']=dict(n=int((~bl.lof).sum()),median=float(bl[~bl.lof].aao.median()))
R['lit']['mwu_p_lof_vs_mis']=float(stats.mannwhitneyu(bl[bl.lof].aao,bl[~bl.lof].aao).pvalue)
# case-reported variants that are frequent in gnomAD
lc=lit[lit.common_flag.fillna(False)].groupby('p').agg(rows=('p','size'),reported=('Reported pathogenicity (from reference)',lambda s:'; '.join(sorted(set(map(str,s))))[:120]),FAF=('gnomAD_FAF','first'),clinvar=('clinvar_cls','first')).sort_values('rows',ascending=False)
# case-reported P/LP-claimed variants absent from ClinVar
nocv=lit[lit.reported_P&lit.p.notna()&lit.clinvar_cls.isna()].groupby('p').size().sort_values(ascending=False)
R['lit']['reportedP_not_in_clinvar']=int(len(nocv))
# ---------- save ----------
cv.to_csv(D+'clinvar_final.csv',index=False); g.to_pickle(D+'gnomad_final.pkl')
with pd.ExcelWriter(O+'PINK1_open_data_results.xlsx') as w:
    pd.DataFrame([['Generated','2026-10-16'],['ClinVar release','2026-10-11 (GRCh38 VCF)'],['gnomAD','v4.1 export 2026-10-16, ENSG00000158828, transcript ENST00000321556.5'],['UniProt','Q9BXM7 (581 aa)'],['MCAF threshold used for BS1 flag',TH]],columns=['item','value']).to_excel(w,sheet_name='README',index=False)
    cols=['cv_id','key','p','aa','Transcript Consequence','vtype','dom','cls','clnsig','stars','revstat','dn','in_gnomad','AF','Allele Count','Homozygote Count','FAF','GroupMax FAF group','BS1_flag','revel_max','revel_tier','cadd','spliceai_ds_max','splice_tier','phylop','cons']
    cv[cols].sort_values(['cls','aa']).to_excel(w,sheet_name='ClinVar_PINK1_annotated',index=False)
    land.to_excel(w,sheet_name='ClinVar_landscape')
    car.to_excel(w,sheet_name='Carrier_freq_by_ancestry',index=False)
    plp_g.to_excel(w,sheet_name='PLP_in_gnomAD',index=False)
    bs1.to_excel(w,sheet_name='BS1_BA1_flags',index=False)
    cv[cv.cls.isin(['VUS','Conflicting'])][cols].sort_values('revel_max',ascending=False).to_excel(w,sheet_name='VUS_insilico_triage',index=False)
    dt.to_excel(w,sheet_name='Domain_enrichment',index=False)
    fx.to_excel(w,sheet_name='Functional_overlay',index=False)
    lc.to_excel(w,sheet_name='Lit_case_variants_frequent')
    nocv.rename('rows').to_frame().to_excel(w,sheet_name='Lit_reportedP_not_ClinVar')
json.dump(R,open(O+'results.json','w'),indent=1,default=lambda x: float(x) if isinstance(x,(np.floating,np.integer)) else str(x))
print(json.dumps(R,indent=0,default=str)[:6000])
print(car[car.set=='P/LP + HC pLoF'][['population','variants_observed','total_AC','q','carrier_1_in','biallelic_per_100k']].to_string())
print(car[car.set=='ClinVar P/LP'][['population','total_AC','q','carrier_1_in','biallelic_per_100k']].to_string())
print(bs1.head(25).to_string())
print(fx[['p','study','functional_class','cls','clinvar_vs_function','gnomAD_AF']].to_string())
print(lc.head(15).to_string())
