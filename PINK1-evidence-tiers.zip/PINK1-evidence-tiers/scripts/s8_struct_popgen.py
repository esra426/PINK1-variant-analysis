import pandas as pd, numpy as np, re, json
from scipy import stats
rng=np.random.default_rng(11)
cv=pd.read_csv('data/clinvar_final.csv'); g=pd.read_pickle('data/gnomad_final.pkl'); cons=np.loadtxt('data/conservation.txt')
O={}
# ---------- A. catalytic-site annotation ----------
SITES={'Gly-rich loop (162–170)':range(162,171),'VAIK Lys219':[219],'Ser228 (autophosphorylation)':[228],'HRD catalytic loop (360–362)':range(360,363),'Activation segment DFG–APE (384–417)':range(384,418)}
core=set(); [core.update(v) for v in SITES.values()]
O['core_n_residues']=len(core); O['kinase_len']=356
ma=[]
for l in open('data/raw/ma2021.txt'):
    if re.match(r'\s+p\.[A-Z][a-z]{2}\d+[A-Z][a-z]{2}\s',l):
        parts=re.split(r'\s{2,}',l.strip())
        if parts[4].lower().startswith(('pathogenic','likely pathogenic')): ma.append(parts[0])
plp=sorted(set(cv[(cv.cls=='P/LP')&(cv.vtype=='Missense')].p.dropna())|set(ma))
pos=lambda L:[int(re.search(r'(\d+)',x).group(1)) for x in L]
P=np.array(pos(plp)); Pk=P[(P>=156)&(P<=511)]
t1k=set(cv[cv.cls=='P/LP'].key)
G=g[(g['VEP Annotation']=='missense_variant')&~g.key.isin(t1k)&g.aa_pos.notna()].aa_pos.astype(int).values; Gk=G[(G>=156)&(G<=511)]
V=cv[cv.cls.isin(['VUS','Conflicting'])&(cv.vtype=='Missense')].aa.dropna().astype(int).values; Vk=V[(V>=156)&(V<=511)]
inC=lambda a: np.isin(a,list(core))
O['plp_kinase_n']=int(len(Pk)); O['plp_in_core']=int(inC(Pk).sum()); O['gn_kinase_n']=int(len(Gk)); O['gn_in_core']=int(inC(Gk).sum()); O['vus_kinase_n']=int(len(Vk)); O['vus_in_core']=int(inC(Vk).sum())
orr,p=stats.fisher_exact([[O['plp_in_core'],len(Pk)-O['plp_in_core']],[O['gn_in_core'],len(Gk)-O['gn_in_core']]]); O['core_OR']=orr; O['core_p']=p
# residue-level expectation: fraction of kinase residues in core
O['core_residue_frac']=len(core)/356
# per-site breakdown
O['per_site']={k:dict(plp=int(np.isin(Pk,list(v)).sum()),gnomad=int(np.isin(Gk,list(v)).sum()),vus=int(np.isin(Vk,list(v)).sum())) for k,v in SITES.items()}
O['plp_core_variants']=[x for x,a in zip(plp,P) if a in core]
# distance to nearest core residue; permutation from gnomAD kinase positions
cl=np.array(sorted(core))
dist=lambda a: np.abs(a[:,None]-cl[None,:]).min(1)
obs=dist(Pk).mean(); null=np.array([dist(rng.choice(Gk,len(Pk),replace=False)).mean() for _ in range(10000)])
O['dist_obs']=float(obs); O['dist_null_mean']=float(null.mean()); O['dist_p']=float(((null<=obs).sum()+1)/(len(null)+1))
# linear clustering: mean pairwise distance
mpd=lambda a: np.abs(a[:,None]-a[None,:])[np.triu_indices(len(a),1)].mean()
obs2=mpd(Pk); null2=np.array([mpd(rng.choice(Gk,len(Pk),replace=False)) for _ in range(10000)])
O['mpd_obs']=float(obs2); O['mpd_null_mean']=float(null2.mean()); O['mpd_p']=float(((null2<=obs2).sum()+1)/(len(null2)+1))
# conservation adjustment: restrict null to gnomAD positions with conservation>=0.95
hc=Gk[cons[Gk-1]>=0.95]; null3=np.array([dist(rng.choice(hc,len(Pk),replace=False)).mean() for _ in range(10000)])
O['dist_null_hc_mean']=float(null3.mean()); O['dist_p_hc']=float(((null3<=obs).sum()+1)/(len(null3)+1)); O['hc_positions']=int(len(hc))
# VUS in core with REVEL
vc=cv[cv.cls.isin(['VUS','Conflicting'])&(cv.vtype=='Missense')&cv.aa.isin(list(core))][['p','cls','revel_max','aa']].sort_values('aa')
vc['cons']=vc.aa.map(lambda a: cons[int(a)-1])
O['vus_core_PP3']=vc[vc.revel_max>=0.644].p.tolist()
vc.to_csv('out/vus_core_sites.csv',index=False)
# ---------- B. observed vs expected homozygotes ----------
POPS=['African/African American','Admixed American','Ashkenazi Jewish','East Asian','European (Finnish)','Middle Eastern','European (non-Finnish)','Amish','South Asian','Remaining']
def oe(r):
    E=0.0; Ob=0
    for pp in POPS:
        an=r[f'Allele Number {pp}']; ac=r[f'Allele Count {pp}']
        if an>0: E+=(an/2)*(ac/an)**2
        Ob+=r[f'Homozygote Count {pp}']
    return pd.Series(dict(obs_hom=int(Ob),exp_hom=E))
sel=g[(g['Filters - joint']=='PASS')&(g['Allele Frequency']>=1e-4)&~g['VEP Annotation'].isin(['intron_variant','3_prime_UTR_variant','5_prime_UTR_variant'])].copy()
sel=pd.concat([sel,sel.apply(oe,axis=1)],axis=1)
sel['p_excess']=[stats.poisson.sf(o-1,e) if o>0 else 1.0 for o,e in zip(sel.obs_hom,sel.exp_hom)]
sel['O_E']=sel.obs_hom/sel.exp_hom
cvc=cv.set_index('key').cls
sel['clinvar']=sel.key.map(cvc)
focus=['p.Gly30Arg','p.Ala494Val','p.Glu55=','p.Ala339Thr','p.Met318Leu','p.Gln115Leu','p.Ala340Thr','p.Asn521Thr','p.Arg501Gln','p.Gly411Ser']
F=sel[sel['Protein Consequence'].isin(focus)][['Protein Consequence','clinvar','Allele Count','Allele Frequency','obs_hom','exp_hom','O_E','p_excess']]
O['homo_focus']=F.round(4).to_dict('records')
# gene-wide: coding variants AF>=1e-4 aggregate
O['homo_total']=dict(n=len(sel),obs=int(sel.obs_hom.sum()),exp=float(sel.exp_hom.sum()))
O['homo_sig_bonf']=sel[sel.p_excess<0.05/len(sel)][['Protein Consequence','obs_hom','exp_hom']].round(3).to_dict('records')
# T1/T2 alleles: obs hom vs exp
t1=cv[(cv.cls=='P/LP')].key
tt=g[g.key.isin(t1)&(g['Filters - joint']=='PASS')].copy(); tt=pd.concat([tt,tt.apply(oe,axis=1)],axis=1)
O['T1_hom']=dict(obs=int(tt.obs_hom.sum()),exp=float(tt.exp_hom.sum()),vars=tt[tt.obs_hom>0]['Protein Consequence'].tolist())
sel.to_csv('out/homozygote_OE.csv',index=False)
json.dump(O,open('out/struct_popgen.json','w'),indent=1,default=str)
print(json.dumps(O,indent=0,default=str)[:5000])
