"""Assemble the PINK1 pathogenic-variant database workbook (relational + user schema)."""
import pandas as pd, numpy as np, re, json, sys
sys.argv=['x']; exec(open('scripts/s14_pathogenic_db.py').read().split('# ---------- master variant list ----------')[0])  # helpers + sources
SP='out/intermediate/'
VT=pd.read_pickle(SP+'VT.pkl'); key2id=json.load(open(SP+'key2id.json'))
src=open('scripts/s14_pathogenic_db.py').read()
blk=src[src.index('ALIAS='):src.index('for r in L.itertuples():')]; exec(blk)   # lit_key, cnv_key, ivs_c
fs_full={fs_codon(p):p for p in list(cv[cv.p.fillna('').str.contains('fs')].p)+list(gp[gp['Protein Consequence'].str.contains('fs')]['Protein Consequence'])}
VTi=VT.set_index('variant_id')
cv_by_p={r.p:r for r in cv.itertuples() if pd.notna(r.p)}
def resolve(raw):
    k=lit_key(raw)
    if k and k.startswith('p.') and 'fs' in k and k not in key2id: k=fs_full.get(fs_codon(k),k)
    return k
def ann(raw):
    """variant-level fields for one reported allele"""
    k=resolve(raw); vid=key2id.get(k) if k else None
    if vid:
        r=VTi.loc[vid]
        return dict(vid=vid,genomic=r.genomic_hgvs,cdna=r.cDNA_hgvs,prot=r.protein_hgvs or r.variant_label,type=r.variant_type,exon=r.exon_intron,region=r.region,
                    cls=r.classification,date=r.classification_date,src=r.classification_source,acmg=r.acmg_criteria_candidates,fx=r.functional_evidence,
                    lit=r.literature_evidence,pop=r.population_frequency,cvid=r.clinvar_id,est=r.evidence_status)
    # allele not reported as pathogenic anywhere: annotate from ClinVar / gnomAD
    c=cv_by_p.get(k) if k else None; gf=gnomad_fields(c.key if c is not None else None,k)
    faf=gf['gnomad_FAF']; cl=str(c.clnsig).replace('_',' ') if c is not None else 'not in ClinVar'
    disc=('benign' in cl.lower() and 'conflicting' not in cl.lower()) or (faf!='' and faf>MCAF)
    return dict(vid='',genomic=c.hgvs_g if c is not None else '',cdna='',prot=(k.replace('p.','p.(')+')') if k and k.startswith('p.') else str(raw),type=c.vtype if c is not None else '',
                exon='',region=region_of(aa_of(k),'') if k else '',cls=cl,date='as of ClinVar release 2026-10-11' if c is not None else '',src='ClinVar aggregate (CLNSIG)' if c is not None else '',
                acmg='',fx=' | '.join(fx.get(k,[])),lit='',pop=gf['population_frequency'],cvid=int(c.cv_id) if c is not None else '',
                est='Discordant: ClinVar B/LB or above MCAF' if disc else 'Not reported as pathogenic')
def supported(e): return e.startswith('Supported') or 'predicted null' in e
def discordant(e): return e.startswith('Discordant')
def level(zyg,alle):
    es=[a['est'] for a in alle]
    if not alle or zyg=='unknown': return 'U'
    if any(discordant(e) for e in es): return 'D'
    if zyg=='homozygous': return 'A' if supported(es[0]) else 'B2'
    if zyg=='compound heterozygous': return 'B1' if len(es)>=2 and all(supported(e) for e in es[:2]) else 'B2'
    return 'C'
STATUS={'A':'confirmed (provisional; homozygous supported allele)','B1':'probable (two supported alleles; phase not reported)','B2':'probable (allele support missing)',
        'C':'uncertain (single variant reported)','D':'not confirmed (discordant allele)','U':'insufficient data'}
def zyg_of(z):
    z=str(z).strip().lower()
    return 'homozygous' if z.startswith('hom') else 'compound heterozygous' if z.startswith('compound') else 'heterozygous' if z=='het' else 'unknown'
# ---------- cases ----------
A_FIELDS=['genetic_test','sequencing_platform','sequencing_center','genetic_sample','sample_id','test_date','report_date','laboratory_report_id','genome_build','reference_transcript','transcript_version','sequencing_method','coverage_mean','coverage_gene','coverage_limitations','variant_calling_pipeline','annotation_pipeline','cnv_analysis','structural_variant_analysis']
VF=['genomic_hgvs','cDNA_hgvs','protein_hgvs','type','exon_intron','region','zygosity','allele_balance','read_depth','inheritance','classification','classification_date','classification_source','acmg_criteria','functional_evidence','literature_evidence','population_frequency','clinvar_id']
C_FIELDS=['father_genotype','mother_genotype','siblings_genotype','segregation_analysis','variant_phase','inheritance_pattern','biallelic_status','second_allele_search','genetic_diagnosis_status','phenotype_consistency','clinical_interpretation','report_recommendations','wgs_status','reanalysis_status','reanalysis_date']
def vblock(n,a,zyg):
    if a is None: return {f'variant{n}_{f}':'' for f in VF}
    return {f'variant{n}_genomic_hgvs':a['genomic'],f'variant{n}_cDNA_hgvs':a['cdna'],f'variant{n}_protein_hgvs':a['prot'],f'variant{n}_type':a['type'],
            f'variant{n}_exon_intron':a['exon'],f'variant{n}_region':a['region'],f'variant{n}_zygosity':zyg,f'variant{n}_allele_balance':'',f'variant{n}_read_depth':'',
            f'variant{n}_inheritance':'',f'variant{n}_classification':a['cls'],f'variant{n}_classification_date':a['date'],f'variant{n}_classification_source':a['src'],
            f'variant{n}_acmg_criteria':a['acmg'],f'variant{n}_functional_evidence':a['fx'],f'variant{n}_literature_evidence':a['lit'],
            f'variant{n}_population_frequency':a['pop'],f'variant{n}_clinvar_id':a['cvid']}
cases=[]; links=[]
for r in L.itertuples():
    raw=str(r._1); parts=split_alleles(raw); z=zyg_of(r.Zygosity)
    al=[ann(x) for x in parts]
    if not any(a['vid'] for a in al): continue
    if z=='homozygous' and len(al)==1: al2=[al[0],al[0]]
    else: al2=al
    lv=level(z,al2 if z!='heterozygous' else al[:1])
    fam=str(r[list(L.columns).index('Presence of PD in family (relationship)')+1]) if pd.notna(r[list(L.columns).index('Presence of PD in family (relationship)')+1]) else ''
    segv=r[list(L.columns).index('Affected family carry same variant')+1]; segv='' if pd.isna(segv) else str(segv)
    cons_=r.Consanguinity if pd.notna(r.Consanguinity) else ''
    aao=r[list(L.columns).index('Age at onset/diagnosis')+1]; aao='' if pd.isna(aao) else aao
    try: aon=float(aao)
    except: aon=None
    cid=f'LIT{r.row:04d}'
    row={'case_id':cid,'source':'Yin & Dieriks 2025 compendium','source_reference':cite(r.Reference),'compendium_row':r.row}
    row.update({f:'' for f in A_FIELDS})
    row.update({'gene':'PINK1','gene_disease_association':DIS})
    row.update(vblock(1,al2[0],z)); row.update(vblock(2,al2[1] if len(al2)>1 else None,z if len(al2)>1 else ''))
    row.update({'father_genotype':'','mother_genotype':'',
        'siblings_genotype':(f'affected relative(s) reported to carry the same variant ({fam})' if segv.startswith('Y') else ''),
        'segregation_analysis':('affected relatives carry the same variant (as reported)' if segv.startswith('Y') else ('affected relative does not carry the variant (as reported)' if segv.startswith('N') else '')),
        'variant_phase':('not applicable (homozygous)' if z=='homozygous' else ('not reported in compendium' if z=='compound heterozygous' else ('not applicable (single variant)' if z=='heterozygous' else ''))),
        'inheritance_pattern':('autosomal recessive (biallelic genotype reported)' if z in ('homozygous','compound heterozygous') else ('single heterozygous; mechanism unresolved' if z=='heterozygous' else '')),
        'biallelic_status':{'homozygous':'biallelic (homozygous)','compound heterozygous':'biallelic (compound heterozygous)','heterozygous':'monoallelic (single variant reported)'}.get(z,'unknown'),
        'second_allele_search':'','genetic_diagnosis_status':STATUS[lv],
        'phenotype_consistency':('early onset (≤50 y), consistent with PINK1-PD' if aon is not None and aon<=50 else ('onset >50 y, later than typical' if aon is not None else '')),
        'clinical_interpretation':f'Reported pathogenicity (original paper): {r[list(L.columns).index("Reported pathogenicity (from reference)")+1]}',
        'report_recommendations':'','wgs_status':'','reanalysis_status':'','reanalysis_date':''})
    row.update({'certainty_level_provisional':lv,'variant1_id':al2[0]['vid'],'variant2_id':(al2[1]['vid'] if len(al2)>1 else ''),'age_at_onset':aao,'sex':r.Sex if pd.notna(r.Sex) else '',
        'ethnicity':r.Ethnicity if pd.notna(r.Ethnicity) else '','family_history':fam,'consanguinity':cons_,'alleles_as_reported':raw,
        'possible_duplicate_key':f'{raw}|{z}|{aao}|{r.Sex if pd.notna(r.Sex) else ""}'})
    cases.append(row)
    for i,a in enumerate(al2 if z!='heterozygous' else al[:1],start=1):
        links.append({'case_id':cid,'allele':i,'variant_id':a['vid'],'allele_as_reported':parts[min(i-1,len(parts)-1)],'protein_hgvs':a['prot'],'cDNA_hgvs':a['cdna'],
                      'zygosity':z,'classification':a['cls'],'evidence_status':a['est'],'clinvar_id':a['cvid']})
CA=pd.DataFrame(cases); LK=pd.DataFrame(links)
dk=CA[CA.age_at_onset!=''].groupby('possible_duplicate_key').case_id.transform('count')
CA['possible_duplicate']=''; CA.loc[dk.index,'possible_duplicate']=np.where(dk>1,'yes (same genotype, zygosity, onset and sex as another row)','')
CA=CA.drop(columns='possible_duplicate_key')
# ---------- unaffected carriers ----------
uc=[]
for sh,d in UC.items():
    for i,r in d.reset_index(drop=True).iterrows():
        raw=str(r['Amino acid change']); parts=split_alleles(re.sub(r'\(.*?\)','',raw)); al=[ann(x) for x in parts]
        if not any(a['vid'] for a in al): continue
        fam=r.get('Family history',''); seg=r.get('Affected family carry same variant',r.get('Affected family carry same mutation',''))
        uc.append({'carrier_id':f'UNAFF-{"A" if sh.startswith("Unaff") else "B"}{i+1:03d}','source_sheet':f'Yin & Dieriks 2025, Suppl. Table 4: {sh}','source_reference':cite(r['Reference']),
            'variants_as_reported':raw,'variant_ids':'; '.join(a['vid'] for a in al if a['vid']),'protein_hgvs':'; '.join(a['prot'] for a in al),
            'zygosity':r['Zygosity'],'classification':'; '.join(a['cls'] for a in al),'evidence_status':'; '.join(a['est'] for a in al),
            'age_at_report':r.get('Age at time of report',''),'sex':r.get('Sex',''),'ethnicity':r.get('Ethnicity',''),'family_history':fam,
            'affected_relatives_carry_variant':seg,'consanguinity':r.get('Consanguinity',''),'reported_pathogenicity':r.get('Reported pathogenicity from reference','')})
UCA=pd.DataFrame(uc).fillna('')
# ---------- MDSGene studies ----------
lines=open('data/raw/MDSGene_PINK1_overview.txt').read().split('\n'); seen={}
for i,l in enumerate(lines):
    m=re.search(r'study=(\d+)&live_patients',l)
    if m:
        win='\n'.join(lines[max(0,i-4):i+3]); nm=re.findall(r'([A-Z][A-Za-zÀ-ÿ\-\' ]+?, (?:19|20)\d\d)',win)
        nu=re.search(r'\s(\d+)\s{3,}(n\.a\.|[A-Z])\s{3,}(n\.a\.|\d+%)\s{3,}(n\.a\.|\d+(?:\(\+/-\d+\))?)',win)
        de=re.search(r'(Mutational|Family study|Case|Other/Mixed)',win)
        if m.group(1) not in seen or (nu and not seen[m.group(1)][2]): seen[m.group(1)]=(nm[-1] if nm else '',de.group(1) if de else '',nu.groups() if nu else ('','','',''))
MD=pd.DataFrame([{'mdsgene_study_id':int(k),'study':v[0],'design':{'Mutational':'mutational screen','Case':'case report / case series','Family study':'family study','Other/Mixed':'other / mixed'}.get(v[1],v[1]),
    'n_patients':int(v[2][0]) if v[2][0] else '','ethnicity_code':v[2][1],'male_percent':v[2][2],'mean_aao_sd':v[2][3]} for k,v in seen.items()])
# ---------- unclassified predicted LoF (gnomAD) ----------
T1k=set(cv[(cv.cls=='P/LP')].key)
def ptc(p,vv,c):
    if vv=='stop_gained': return c
    m=re.match(r'p\.[A-Z][a-z]{2}(\d+)[A-Z][a-z]{2}fsTer(\d+)',str(p)); return 3*(int(m.group(1))+int(m.group(2))-1) if m else np.nan
gg=g.copy(); gg['c_num']=gg['Transcript Consequence'].str.extract(r'c\.(\d+)')[0].astype(float)
gg['ptc']=[ptc(p,vv,c) for p,vv,c in zip(gg['Protein Consequence'],gg['VEP Annotation'],gg.c_num)]
blb=set(cv[cv.cls=='B/LB'].key); ok=~gg.Flags.fillna('').str.contains('lof_flag|lcr')&~gg.key.isin(blb)
lof=(gg['VEP Annotation'].isin(['stop_gained','frameshift_variant'])&(gg.ptc<=1438)&ok)|(gg['VEP Annotation'].isin(['splice_acceptor_variant','splice_donor_variant'])&ok)
inVT=set(VT.gnomad_id)
PL=gg[lof&~gg.key.isin(T1k)&~gg['gnomAD ID'].isin(inVT)][['gnomAD ID','Transcript Consequence','Protein Consequence','VEP Annotation','Filters - joint','Allele Count','Allele Number','Allele Frequency','GroupMax FAF frequency','GroupMax FAF group','Homozygote Count']].copy()
PL['ClinVar_class']=PL['gnomAD ID'].map(cv.set_index('key').cls).fillna('not in ClinVar')
PL['exon_intron']=PL['Transcript Consequence'].map(exon_of_c); PL['note']='predicted null allele (NMD-predicted truncating or canonical splice); not classified as pathogenic; counted in tier T2'
PL=PL.rename(columns={'gnomAD ID':'gnomad_id','Transcript Consequence':'cDNA_hgvs','Protein Consequence':'protein_hgvs','VEP Annotation':'vep_consequence','Filters - joint':'gnomad_filter',
    'Allele Count':'gnomad_AC','Allele Number':'gnomad_AN','Allele Frequency':'gnomad_AF','GroupMax FAF frequency':'gnomad_FAF','GroupMax FAF group':'gnomad_FAF_group','Homozygote Count':'gnomad_hom'})
# ---------- outputs ----------
VOUT=VT.drop(columns=['_aa','_key']).copy()
cols=['variant_id','evidence_status','gene','gene_disease_association','genomic_hgvs','cDNA_hgvs','cDNA_as_reported','protein_hgvs','variant_label','aliases','variant_type','exon_intron','region','conservation',
      'pathogenic_sources','n_sources','classification','review_stars','review_status','classification_date','classification_source','clinvar_condition','acmg_criteria_candidates',
      'functional_evidence','literature_evidence','listed_in_MDSGene','population_frequency','gnomad_id','gnomad_AC','gnomad_AN','gnomad_AF','gnomad_FAF','gnomad_FAF_group','gnomad_hom','gnomad_filter','clinvar_id','review_flags']
VOUT=VOUT[cols]
CA.to_pickle(SP+'CA.pkl'); LK.to_pickle(SP+'LK.pkl'); UCA.to_pickle(SP+'UCA.pkl'); MD.to_pickle(SP+'MD.pkl'); PL.to_pickle(SP+'PL.pkl'); VOUT.to_pickle(SP+'VOUT.pkl')
print('variants',len(VOUT),'cases',len(CA),'links',len(LK),'unaffected',len(UCA),'mdsgene',len(MD),MD.n_patients.replace('',0).sum(),'predicted LoF',len(PL))
print(CA.certainty_level_provisional.value_counts().to_dict()); print(CA.biallelic_status.value_counts().to_dict()); print((CA.possible_duplicate!='').sum())
