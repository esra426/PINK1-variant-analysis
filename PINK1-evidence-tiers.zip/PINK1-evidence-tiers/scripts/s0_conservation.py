from Bio import Align
from Bio.Align import substitution_matrices
import numpy as np
hum=''.join(l.strip() for l in open('data/raw/pink1.fasta') if not l.startswith('>'))
orth=[];h=None
for l in open('data/raw/orthologs.fasta'):
    if l.startswith('>'): h=l[1:].strip()
    else: orth.append((h,l.strip()))
al=Align.PairwiseAligner(); al.substitution_matrix=substitution_matrices.load('BLOSUM62'); al.open_gap_score=-10; al.extend_gap_score=-0.5; al.mode='global'
ident=np.zeros(len(hum)); cover=np.zeros(len(hum)); keep=0
for h,s in orth:
    a=al.align(hum,s)[0]
    pid=sum(1 for (hs,he),(os_,oe) in zip(*a.aligned) for k in range(he-hs) if hum[hs+k]==s[os_+k])/len(hum)
    if pid<0.3: continue
    keep+=1
    for (hs,he),(os_,oe) in zip(*a.aligned):
        for k in range(he-hs):
            cover[hs+k]+=1; ident[hs+k]+= hum[hs+k]==s[os_+k]
cons=ident/np.maximum(keep,1)
np.savetxt('data/conservation.txt',cons); print('orthologs used',keep, 'mean cons',cons.mean().round(3))
