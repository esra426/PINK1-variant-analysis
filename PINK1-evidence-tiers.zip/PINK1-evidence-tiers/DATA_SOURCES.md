# Data sources, licences and the attribution sentence for each

| Dataset | Version / access | Used for | Licence / terms | Redistributed here |
|---|---|---|---|---|
| ClinVar (NCBI) | VCF release 11 Oct 2026, GRCh38; PINK1 region chr1:20,633,253–20,656,420 | Clinical classifications, review status, conditions | NCBI public data; attribution to ClinVar requested | Yes: `data/raw/clinvar_pink1_region.vcf` |
| gnomAD (Broad Institute) | v4.1 call set, browser export labelled v4.1.2, ENSG00000158828, downloaded 16 Oct 2026 (MD5 4028a2648c053bde2622441dc43f3f51) | Allele counts, frequencies, GroupMax FAF, homozygotes, annotations | Open Database License (ODbL v1.0); citation requested | Yes: `data/raw/gnomAD_v4.1.2_ENSG00000158828_2026_10_16_16_34_55.csv` |
| UniProtKB | Q9BXM7 and PINK1 orthologs, downloaded 16 Oct 2026 | Reference sequence, conservation | CC BY 4.0 | Yes: `data/raw/*.fasta` |
| Ma et al. 2021, npj Parkinson's Disease 7:113 | Table 1 and Supplementary Table 1 | Functional and combined classifications of missense variants | CC BY 4.0 (open access) | Yes, as extracted text: `data/raw/ma2021.txt` |
| Broadway et al. 2022, Cells 11:2426 | Results tables | Kinase-activity and stability assays | CC BY 4.0 (open access) | Yes, as extracted text: `data/raw/broadway.txt` |
| Yin & Dieriks 2025, J Parkinsons Dis 15:41–65 | Supplementary Tables 2 and 4 | Published cases and unaffected carriers | Publisher terms; download from the publisher | No: download (see `data/raw/README.md`); only re-extracted, cited variables are in `data/derived/` |
| MDSGene (University of Lübeck) | PINK1 pages, accessed 19 Oct 2026 | Coverage check of published mutations | Website content © University of Lübeck | No: save the page text yourself (see `data/raw/README.md`) |

## Sentences to include when you use these data

**ClinVar**
> Variant classifications were obtained from ClinVar (National Center for Biotechnology Information; VCF release of 11 October 2026; https://www.ncbi.nlm.nih.gov/clinvar/) (Landrum et al., 2018).

**gnomAD** (data availability and acknowledgement)
> Population data were obtained from the Genome Aggregation Database (gnomAD) v4.1 (https://gnomad.broadinstitute.org), released under the Open Database License (ODbL v1.0) (Chen et al., 2024; Karczewski et al., 2020; Lek et al., 2016).
>
> The authors thank the Genome Aggregation Database (gnomAD) and the groups that provided exome and genome variant data to this resource. A full list of contributing groups can be found at https://gnomad.broadinstitute.org/about.

**UniProt**
> Protein sequences were obtained from UniProtKB (entry Q9BXM7 and orthologs; CC BY 4.0) (UniProt Consortium, 2025).

**Functional studies**
> Functional data were taken from Ma et al. (2021) and Broadway et al. (2022), both published under CC BY 4.0.

**Published cases**
> Case-level data were re-extracted from the supplementary tables of Yin and Dieriks (2025) and are cited; the original tables are not reproduced.

**MDSGene**
> The MDSGene database (University of Lübeck; https://www.mdsgene.org; accessed 19 October 2026) was consulted to check coverage of published mutations; its content is not redistributed.

## References

- Broadway BJ, et al. Systematic functional analysis of PINK1 and PRKN coding variants. Cells. 2022;11:2426. https://doi.org/10.3390/cells11152426
- Chen S, et al. A genomic mutational constraint map using variation in 76,156 human genomes. Nature. 2024;625:92–100. https://doi.org/10.1038/s41586-023-06045-0
- Karczewski KJ, et al. The mutational constraint spectrum quantified from variation in 141,456 humans. Nature. 2020;581:434–443. https://doi.org/10.1038/s41586-020-2308-7
- Landrum MJ, et al. ClinVar: improving access to variant interpretations and supporting evidence. Nucleic Acids Res. 2018;46:D1062–D1067. https://doi.org/10.1093/nar/gkx1153
- Lek M, et al. Analysis of protein-coding genetic variation in 60,706 humans. Nature. 2016;536:285–291. https://doi.org/10.1038/nature19057
- Ma KY, et al. Systematic analysis of PINK1 variants of unknown significance shows intact mitophagy function for most variants. npj Parkinsons Dis. 2021;7:113. https://doi.org/10.1038/s41531-021-00258-8
- UniProt Consortium. UniProt: the Universal Protein Knowledgebase in 2025. Nucleic Acids Res. 2025;53:D609–D617. https://doi.org/10.1093/nar/gkae1010
- Yin EP, Dieriks BV. Rethinking 'rare' PINK1 Parkinson's disease. J Parkinsons Dis. 2025;15:41–65. https://doi.org/10.1177/1877718X241304814
