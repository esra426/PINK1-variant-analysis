#!/usr/bin/env bash
# Reproduce all analyses from the raw inputs in data/raw (see DATA_SOURCES.md for files you must download yourself).
set -euo pipefail
mkdir -p out/intermediate figures
python scripts/s1_harmonize.py        # ClinVar PINK1 records, join to gnomAD, exon map
python scripts/s0_conservation.py     # ortholog identity per residue
python scripts/s2_analyses.py         # ClinVar landscape, MCAF/BS1, in silico tiers, literature flags
python scripts/s6_revision.py         # NMD rule, AUCs, domain tests
python scripts/s7_final.py            # T1 counts and sensitivity sets
python scripts/s8_struct_popgen.py    # catalytic elements, permutation, homozygote O/E
python scripts/s9_tiers_final.py      # evidence tiers T1–T3, CIs (Table 2, Table 3, Table S4)
python scripts/s10_tables_update.py . # formats Tables 2 and 3
python scripts/s5_figs.py             # Figures 1, 3, 4 and S1
python scripts/s11_fig_carrier.py . figures/fig3.png   # Figure 2
python scripts/s13_review_checks.py   # independent comparison set, cis bound, T1 homozygotes
# Pathogenic-mutation tables (need the Yin & Dieriks supplementary tables and the MDSGene text in data/raw)
python scripts/s14_pathogenic_db.py
python scripts/s15_build_workbook.py
python scripts/s17_filled_table.py
python scripts/s18_write_filled_xlsx.py
