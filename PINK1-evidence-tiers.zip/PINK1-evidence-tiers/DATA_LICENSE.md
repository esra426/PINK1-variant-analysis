# Licence for derived data

The tables in `data/derived/` are made available under the Open Database License v1.0 (ODbL):
https://opendatacommons.org/licenses/odbl/1-0/

They contain data derived from the Genome Aggregation Database (gnomAD), which is released under the ODbL. If you publicly use or share these tables or a database derived from them, you must attribute the sources listed in `DATA_SOURCES.md` and share any adapted database under the ODbL.

Individual contents are also subject to their sources' terms: ClinVar (attribution requested), UniProt and the functional studies (CC BY 4.0), and Yin & Dieriks (2025) (cite the original article).
